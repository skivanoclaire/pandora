# Deep Learning

**Kategori:** Klasifikasi | **Level:** Lanjut

## Ringkasan
Deep Learning adalah cabang machine learning yang menggunakan jaringan syaraf dengan banyak lapisan tersembunyi (deep). Dengan kapasitas representasi yang besar, deep learning mendominasi tugas-tugas pada citra, suara, dan teks.

## Arsitektur Populer

| Arsitektur | Domain | Contoh Aplikasi |
|------------|--------|-----------------|
| CNN (Convolutional NN) | Citra | Face recognition, medical imaging |
| RNN / LSTM / GRU | Sequence | Time series, language modeling |
| Transformer | Sequence/teks | GPT, BERT, ChatGPT |
| Autoencoder | Reduksi/Generative | Anomaly detection |
| GAN | Generative | Image synthesis |

## Mengapa "Deep" Bekerja
Setiap lapisan mempelajari abstraksi yang lebih tinggi:
- Lapisan awal: edge, pojok, warna.
- Lapisan tengah: bentuk, tekstur.
- Lapisan akhir: objek, wajah.

## Bahan Wajib
- **GPU** atau TPU untuk pelatihan praktis.
- **Framework**: TensorFlow/Keras, PyTorch.
- **Data**: ribuan-jutaan sample (atau pakai transfer learning).

## Studi Kasus PANDORA
- **CNN** untuk face recognition di mesin presensi → menggantikan fingerprint yang rentan saat pandemi.
- **LSTM** untuk memprediksi pola kehadiran 7 hari ke depan per OPD.
- **Transformer** mini untuk klasifikasi laporan keluhan masyarakat di portal e-Layanan DKISP.

## Pitfalls
- Overengineering: deep learning untuk masalah kecil = waste. Coba klasik dulu.
- Butuh data dan compute besar.
- Sulit dijelaskan ke non-teknis.
- Privacy concern pada data wajah.

## Kaitan
- → [JST](05-jst.md)
- → [Computer Vision](../07-data-tak-terstruktur/05-computer-vision.md)
- → [Data Augmentation](../02-data-engineering/07-data-augmentation.md)

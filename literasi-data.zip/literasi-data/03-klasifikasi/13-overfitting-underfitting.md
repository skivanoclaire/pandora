# Overfitting & Underfitting

**Kategori:** Klasifikasi | **Level:** Dasar

## Ringkasan
Dua masalah utama dalam machine learning. Underfitting = model terlalu sederhana, gagal menangkap pola. Overfitting = model terlalu kompleks, menghafal data training termasuk noisenya, dan buruk di data baru.

## Ciri-ciri

| Kondisi | Training Error | Test Error |
|---------|---------------|------------|
| Underfit | Tinggi | Tinggi |
| Good fit | Rendah | Rendah |
| Overfit | Sangat rendah | Tinggi |

## Analogi
- **Underfit:** Siswa yang belum belajar. Gagal di latihan dan ujian.
- **Overfit:** Siswa yang menghafal kunci jawaban. Benar di latihan, tapi ujian soalnya beda sedikit dia gagal.
- **Good fit:** Siswa yang memahami konsep. Baik di keduanya.

## Strategi Mengatasi

### Overfitting
- Tambah data training.
- Regularisasi (L1/L2, dropout).
- Kurangi kompleksitas model.
- Early stopping.
- Cross-validation.
- Data augmentation.

### Underfitting
- Tambah fitur / feature engineering.
- Gunakan model lebih kompleks.
- Kurangi regularisasi.
- Training lebih lama.

## Studi Kasus PANDORA
Model JST dengan 5 hidden layer pada data 1000 pegawai:
- Akurasi train: 99%, akurasi test: 70% → overfit.
- Solusi: kurangi ke 2 layer, tambah dropout 0.2, pakai early stopping.

Setelah perbaikan:
- Akurasi train: 85%, akurasi test: 82% → good fit.

## Deteksi dengan Kurva Pembelajaran
Plot training vs validation error saat epoch bertambah:
- Dua kurva rendah & berdekatan → good fit.
- Train terus turun, validation naik → overfit (early stopping point).

## Kaitan
- → [JST](05-jst.md), [Deep Learning](06-deep-learning.md)
- → [Performance Klasifikasi](07-performance-klasifikasi.md)
- → [Data Augmentation](../02-data-engineering/07-data-augmentation.md)

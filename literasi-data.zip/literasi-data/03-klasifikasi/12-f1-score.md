# F1-Score

**Kategori:** Klasifikasi | **Level:** Dasar

## Ringkasan
F1-Score adalah mean harmonik dari presisi dan recall. Memberi satu angka yang menyeimbangkan keduanya. Sangat berguna pada data imbalanced ketika akurasi menyesatkan.

## Rumus
$$F_1 = 2 \cdot \frac{\text{Precision} \cdot \text{Recall}}{\text{Precision} + \text{Recall}}$$

Bentuk umum (Fβ):
$$F_\beta = (1 + \beta^2) \cdot \frac{P \cdot R}{\beta^2 \cdot P + R}$$

- β=1 → F1 (seimbang).
- β=2 → recall dibobotkan 2x.
- β=0.5 → presisi dibobotkan 2x.

## Studi Kasus PANDORA
Dari contoh sebelumnya: Precision=40%, Recall=80%.
- F1 = 2 × (0.4 × 0.8) / (0.4 + 0.8) = 0.64 / 1.2 = **53.3%**.

Dibanding akurasi 93%, F1-Score memberikan gambaran lebih jujur tentang performa model pada kelas minoritas.

## Variasi Multikelas
- **Macro-F1** — rata-rata F1 per kelas (semua kelas setara).
- **Micro-F1** — agregat TP/FP/FN lebih dulu (didominasi kelas mayoritas, = akurasi untuk single-label).
- **Weighted-F1** — rata-rata tertimbang frekuensi kelas.

```python
from sklearn.metrics import f1_score
f1_score(y_true, y_pred, average='macro')
```

## Pitfalls
- F1 mean harmonik "menghukum" ketidakseimbangan P dan R; jangan bingung dengan mean aritmetik.
- F1 tinggi tidak selalu berarti model baik — selalu lihat P dan R secara terpisah juga.

## Kaitan
- → [Presisi](10-presisi.md), [Recall](11-recall.md)
- → [Confusion Matrix](08-confusion-matrix.md)

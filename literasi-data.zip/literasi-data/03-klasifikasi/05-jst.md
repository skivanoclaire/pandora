# Jaringan Syaraf Tiruan (JST)

**Kategori:** Klasifikasi | **Level:** Menengah

## Ringkasan
Jaringan Syaraf Tiruan (Artificial Neural Network, ANN) adalah model yang terinspirasi dari neuron biologis. Tersusun dari lapisan neuron yang saling terhubung dengan bobot, dilatih melalui backpropagation untuk meminimalkan error.

## Arsitektur Dasar

```
Input  →  Hidden Layer(s)  →  Output
 x₁  ───┐
 x₂  ───┼─── Σ → f(z) → ... → ŷ
 x₃  ───┘
      (bobot w, bias b)
```

Setiap neuron: $z = \sum w_i x_i + b$, lalu dipasang melalui fungsi aktivasi (sigmoid, ReLU, tanh).

## Fungsi Aktivasi Umum
- **Sigmoid:** $\sigma(z) = 1/(1+e^{-z})$ — output 0-1.
- **ReLU:** $\max(0, z)$ — paling populer di hidden layer.
- **Softmax** — di output untuk multikelas, menghasilkan probabilitas.

## Backpropagation
Algoritma pelatihan:
1. Forward pass: hitung prediksi.
2. Hitung loss (MSE / cross-entropy).
3. Backward pass: hitung gradien ∂loss/∂w untuk setiap bobot.
4. Update bobot: $w \leftarrow w - \eta \cdot \nabla w$.

## Studi Kasus PANDORA
JST 2 hidden layer untuk klasifikasi "Disiplin / Sedang / Buruk":
- Input: 15 fitur numerik (sudah scaling).
- Hidden: [32, 16] dengan ReLU.
- Output: 3 neuron softmax.

```python
from sklearn.neural_network import MLPClassifier
mlp = MLPClassifier(hidden_layer_sizes=(32,16), max_iter=500)
mlp.fit(X_train, y_train)
```

## Pitfalls
- Butuh data banyak; overfit jika data kecil.
- Sulit diinterpretasi (black box).
- Sensitif terhadap skala fitur dan inisialisasi bobot.

## Kaitan
- → [Deep Learning](06-deep-learning.md)
- → [Overfitting & Underfitting](13-overfitting-underfitting.md)

# K-Nearest Neighbour (KNN)

**Kategori:** Klasifikasi | **Level:** Dasar

## Ringkasan
KNN adalah algoritma klasifikasi berbasis jarak yang sangat sederhana: untuk memprediksi label data baru, cari K tetangga terdekat dari data training, lalu ambil mayoritas label mereka.

## Cara Kerja

1. Tentukan K (jumlah tetangga, misal 5).
2. Hitung jarak data baru ke semua data training (biasanya Euclidean).
3. Ambil K tetangga terdekat.
4. Kelas mayoritas di antara K tetangga = prediksi.

**Rumus Jarak Euclidean:**
$$d(p,q) = \sqrt{\sum_{i=1}^{n}(p_i - q_i)^2}$$

Alternatif: Manhattan, Minkowski, Cosine.

## Memilih K
- K kecil (misal 1) → sensitif noise, overfit.
- K besar → terlalu smooth, underfit.
- Rule of thumb: K = √N, coba nilai ganjil agar tidak tie.
- Cross-validation untuk K optimal.

## Studi Kasus PANDORA
Pegawai baru A dengan fitur (umur=40, rata_telat=8, alpa=2). Cari 5 tetangga terdekat di data historis → 4 dari 5 masuk kelas "Disiplin" → prediksi Disiplin.

```python
from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train_scaled, y_train)
knn.predict(X_new)
```

**Penting:** selalu scaling fitur sebelum KNN, karena jarak sensitif skala.

## Pitfalls
- Tanpa scaling, fitur dengan rentang besar (misal gaji 5jt) mendominasi fitur kecil (umur 40).
- Lambat saat prediksi pada dataset sangat besar (bisa dipercepat dengan KD-Tree, Ball-Tree, atau approximate NN).
- Curse of dimensionality: semua titik jadi "sama jauh" di dimensi tinggi.

## Kaitan
- → [Algoritma Klasifikasi](01-algoritma-klasifikasi.md)
- → [Data Transformation](../02-data-engineering/08-data-transformation.md) (scaling)

# Recall (Sensitivity)

**Kategori:** Klasifikasi | **Level:** Dasar

## Ringkasan
Recall adalah proporsi kasus positif yang berhasil ditangkap model. Menjawab: "Dari semua yang sebenarnya positif, berapa yang model temukan?".

## Rumus
$$\text{Recall} = \frac{TP}{TP + FN}$$

## Interpretasi
- Recall tinggi → sedikit kasus positif yang terlewat.
- Recall rendah → banyak kasus positif yang lolos tidak terdeteksi.

## Studi Kasus PANDORA
Dari confusion matrix (TP=40, FN=10):
- Recall = 40 / (40 + 10) = **80%**.

Artinya: dari 50 pegawai yang benar-benar alpa kronis, model berhasil menandai 40 (80%) tetapi melewatkan 10 (20%).

**Implikasi:** untuk program pembinaan pegawai, recall 80% cukup baik, tapi 10 orang yang terlewat tidak akan dibina — apakah kita terima risiko itu?

## Kapan Recall Penting
- Biaya FN tinggi (pasien kanker tidak terdeteksi, pelanggaran keamanan terlewat).
- Penemuan awal masalah kritis.
- Saat screening (lebih baik salah tuduh daripada terlewat).

## Trade-off
Recall naik = presisi biasanya turun. Atur threshold sesuai prioritas:
- Screening: utamakan recall.
- Tuduhan formal: utamakan presisi.
- Keseimbangan: F1-Score.

## Pitfalls
- Recall 100% mudah dicapai dengan memprediksi SEMUA sebagai positif (tapi presisi hancur).
- Dalam multikelas, laporkan per-kelas recall dan rata-ratanya (macro/weighted).

## Kaitan
- → [Presisi](10-presisi.md)
- → [F1-Score](12-f1-score.md)
- → [Confusion Matrix](08-confusion-matrix.md)

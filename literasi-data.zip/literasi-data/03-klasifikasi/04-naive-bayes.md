# Naive Bayes

**Kategori:** Klasifikasi | **Level:** Menengah

## Ringkasan
Naive Bayes adalah klasifier probabilistik berbasis Teorema Bayes dengan asumsi "naif" bahwa semua fitur saling independen. Sederhana, cepat, dan sering sangat akurat — terutama untuk klasifikasi teks.

## Teorema Bayes

$$P(C|X) = \frac{P(X|C) \cdot P(C)}{P(X)}$$

Di mana:
- $P(C|X)$ = posterior, peluang kelas C diberikan fitur X.
- $P(X|C)$ = likelihood.
- $P(C)$ = prior.
- $P(X)$ = bukti (konstan untuk semua kelas).

Asumsi independensi membuat perhitungan menjadi:
$$P(X|C) = \prod_{i=1}^{n} P(x_i | C)$$

## Varian
- **Gaussian NB** — fitur numerik diasumsikan terdistribusi normal.
- **Multinomial NB** — fitur diskrit (count), populer untuk teks (TF).
- **Bernoulli NB** — fitur biner (ada/tidak).

## Studi Kasus PANDORA
Memprediksi pegawai akan terlambat besok berdasar fitur kategorik (hari, cuaca, OPD, golongan):

```
P(Telat | Senin, Hujan) = 
  P(Senin|Telat) × P(Hujan|Telat) × P(Telat) / Z
```

Setelah dihitung dari data historis: P(Telat|Senin, Hujan) = 0.72 → flag.

```python
from sklearn.naive_bayes import GaussianNB, MultinomialNB
nb = GaussianNB()
nb.fit(X_train, y_train)
```

## Pitfalls
- Asumsi independensi sering tidak realistis (umur & golongan berkorelasi), namun model tetap bekerja baik.
- Probabilitas nol pada fitur yang tidak pernah muncul → pakai Laplace smoothing.
- Tidak cocok jika ada fitur yang sangat dependent.

## Kaitan
- → [TF-IDF](../07-data-tak-terstruktur/04-tf-idf.md) (NB klasik untuk teks)
- → [Algoritma Klasifikasi](01-algoritma-klasifikasi.md)

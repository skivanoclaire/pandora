# Performance Klasifikasi

**Kategori:** Klasifikasi | **Level:** Dasar

## Ringkasan
Setelah model klasifikasi dilatih, kita harus mengukur seberapa baik ia bekerja. Tidak ada satu metrik yang cocok untuk semua kasus — pemilihan metrik bergantung pada konteks bisnis dan keseimbangan kelas.

## Metrik Utama

| Metrik | Cocok untuk | Catatan |
|--------|-------------|---------|
| Akurasi | Kelas seimbang | Menyesatkan saat imbalance |
| Presisi | Saat false positive mahal | Ex: mendeteksi pegawai disiplin |
| Recall | Saat false negative mahal | Ex: mendeteksi pelanggaran |
| F1-Score | Trade-off P & R | Mean harmonik |
| ROC-AUC | Klasifikasi biner umum | Tidak peka thresholding |
| PR-AUC | Imbalance kuat | Lebih informatif dari ROC |
| Log Loss | Probabilitas kalibrasi | Untuk model probabilistik |

## Alur Evaluasi
1. Pisahkan test set yang tidak pernah dilihat model.
2. Lakukan prediksi pada test set.
3. Bangun confusion matrix.
4. Hitung metrik yang relevan.
5. Bandingkan dengan baseline (misal "selalu prediksi kelas mayoritas").

## Studi Kasus PANDORA
Model deteksi "Pegawai Berisiko Alpa". Karena kelas alpa hanya 5%:
- Akurasi 95% mungkin diperoleh hanya dengan selalu menebak "tidak alpa" → tidak berguna.
- **Recall** lebih penting: jangan sampai pegawai berisiko terlewat.
- Laporkan: precision, recall, F1, dan PR-AUC.

## Pitfalls
- Metrik tunggal sering menyesatkan.
- Test set bocor ke train → angka palsu.
- Pilih metrik SEBELUM training, bukan setelah lihat hasil.

## Kaitan
- → [Confusion Matrix](08-confusion-matrix.md)
- → [Akurasi](09-akurasi.md), [Presisi](10-presisi.md), [Recall](11-recall.md), [F1-Score](12-f1-score.md)

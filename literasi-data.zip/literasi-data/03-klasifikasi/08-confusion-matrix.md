# Confusion Matrix

**Kategori:** Klasifikasi | **Level:** Dasar

## Ringkasan
Confusion matrix adalah tabel yang membandingkan label prediksi dengan label sebenarnya. Semua metrik klasifikasi (akurasi, presisi, recall, F1) diturunkan dari 4 angka di tabel ini.

## Struktur (Biner)

|                  | Prediksi: Positif | Prediksi: Negatif |
|------------------|-------------------|-------------------|
| **Aktual: Positif** | TP (True Positive) | FN (False Negative) |
| **Aktual: Negatif** | FP (False Positive) | TN (True Negative) |

- **TP** — prediksi positif, sebenarnya positif (benar).
- **TN** — prediksi negatif, sebenarnya negatif (benar).
- **FP** — prediksi positif, padahal negatif (alarm palsu, Type I error).
- **FN** — prediksi negatif, padahal positif (kelewat, Type II error).

## Studi Kasus PANDORA

Model memprediksi 1000 pegawai sebagai "Alpa Kronis":

|                  | Prediksi: Alpa | Prediksi: Tidak Alpa |
|------------------|---------------|----------------------|
| **Aktual: Alpa** | TP = 40 | FN = 10 |
| **Aktual: Tidak Alpa** | FP = 60 | TN = 890 |

Interpretasi:
- 40 pegawai benar-benar berisiko dan terdeteksi.
- 10 pegawai berisiko tapi tidak terdeteksi (ini berbahaya).
- 60 pegawai dikira berisiko padahal tidak → bisa membuat jengkel.
- 890 pegawai aman terdeteksi aman.

## Multikelas
Untuk N kelas, matriks N×N. Diagonal = benar, off-diagonal = kebingungan antar kelas.

```python
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
cm = confusion_matrix(y_true, y_pred)
ConfusionMatrixDisplay(cm).plot()
```

## Pitfalls
- Urutan baris/kolom tergantung library; selalu baca dengan teliti.
- Pada kelas sangat imbalanced, visualisasi absolut bisa menyesatkan — normalisasi per baris.

## Kaitan
- → [Akurasi](09-akurasi.md), [Presisi](10-presisi.md), [Recall](11-recall.md), [F1-Score](12-f1-score.md)
- → [Performance Klasifikasi](07-performance-klasifikasi.md)

# Algoritma Klasifikasi

**Kategori:** Klasifikasi | **Level:** Dasar

## Ringkasan
Algoritma klasifikasi adalah metode supervised learning yang mempelajari pemetaan dari fitur input ke label kelas diskrit berdasarkan data pelatihan berlabel. Setelah dilatih, model dapat menebak label untuk data baru.

## Alur Umum

```
Data berlabel (X, y)
      ↓
 Split train/test
      ↓
   Training → Model
      ↓
  Prediksi pada test
      ↓
   Evaluasi (metric)
      ↓
Deploy untuk data baru
```

## Jenis Klasifikasi
- **Biner** — 2 kelas (tepat waktu / terlambat).
- **Multikelas** — >2 kelas eksklusif (disiplin / sedang / buruk).
- **Multilabel** — satu instance bisa punya >1 label sekaligus.

## Algoritma Populer

| Algoritma | Kekuatan | Kelemahan |
|-----------|----------|-----------|
| KNN | Sederhana, tidak parametric | Lambat pada dataset besar |
| Decision Tree (C4.5) | Interpretable | Overfit, tidak stabil |
| Naive Bayes | Cepat, baik untuk teks | Asumsi independensi |
| JST / NN | Kuat untuk pola kompleks | Butuh banyak data |
| Random Forest | Akurat & tahan noise | Sulit diinterpretasi |
| SVM | Efektif di dimensi tinggi | Scaling penting |
| Gradient Boosting | Sering juara kompetisi | Tuning ribet |

## Studi Kasus PANDORA
Target: klasifikasi pegawai "Disiplin / Tidak Disiplin" berdasar 30 hari presensi.

Fitur: rata-rata menit telat, jumlah alpa, jumlah izin, golongan, umur, jarak rumah-kantor.

Bandingkan KNN, C4.5, Naive Bayes pada data yang sama → pilih yang F1-nya tertinggi.

## Kaitan
- → [Performance Klasifikasi](07-performance-klasifikasi.md)
- → [KNN](02-knn.md), [C4.5](03-c45.md), [Naive Bayes](04-naive-bayes.md)

# Presisi (Precision)

**Kategori:** Klasifikasi | **Level:** Dasar

## Ringkasan
Presisi adalah proporsi prediksi positif yang benar-benar positif. Menjawab pertanyaan: "Dari semua yang model bilang positif, berapa yang benar?".

## Rumus
$$\text{Precision} = \frac{TP}{TP + FP}$$

## Interpretasi
- Presisi tinggi → sedikit alarm palsu.
- Presisi rendah → banyak prediksi positif yang ternyata negatif.

## Studi Kasus PANDORA
Dari confusion matrix (TP=40, FP=60):
- Presisi = 40 / (40 + 60) = **40%**.

Artinya: dari 100 pegawai yang diflag "Alpa Kronis", hanya 40 yang benar. 60 sisanya disalahkan tanpa dasar.

**Implikasi:** jika sistem akan digunakan untuk teguran formal, presisi rendah akan merusak kepercayaan dan menyakitkan secara administratif. Naikkan threshold prediksi sampai presisi acceptable.

## Kapan Presisi Penting
- Biaya FP tinggi (menuduh orang tidak bersalah, salah kirim email penting, salah blok akun).
- Audit dan keputusan formal.
- Spam filter (lebih baik spam lewat daripada email penting masuk spam).

## Trade-off dengan Recall
Menaikkan threshold → presisi naik, recall turun. Selalu ada trade-off.

## Pitfalls
- Mengejar presisi 100% sering berarti hampir tidak pernah memprediksi positif.
- Tidak relevan jika tidak ada kelas "positif" yang jelas didefinisikan.

## Kaitan
- → [Recall](11-recall.md)
- → [F1-Score](12-f1-score.md)
- → [Confusion Matrix](08-confusion-matrix.md)

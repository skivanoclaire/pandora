# Akurasi (Accuracy)

**Kategori:** Klasifikasi | **Level:** Dasar

## Ringkasan
Akurasi adalah proporsi prediksi yang benar dari total prediksi. Metrik paling intuitif, tetapi sering menyesatkan pada data imbalanced.

## Rumus
$$\text{Accuracy} = \frac{TP + TN}{TP + TN + FP + FN}$$

## Studi Kasus PANDORA
Dari confusion matrix (1000 pegawai):
- TP=40, TN=890, FP=60, FN=10.
- Akurasi = (40 + 890) / 1000 = **93%**.

Kedengaran bagus. **Tapi:** baseline yang selalu menjawab "Tidak Alpa" memberi akurasi (0+950)/1000 = 95%. Model kita justru lebih buruk dari menebak konstan!

Ini contoh klasik **paradoks akurasi** — pada data imbalance, akurasi tinggi belum tentu berarti model bagus.

## Kapan Akurasi Cocok
- Kelas seimbang (mendekati 50/50 untuk biner).
- Biaya FP dan FN setara.
- Kebutuhan pelaporan eksekutif yang sederhana.

## Kapan Tidak Cocok
- Imbalance kuat (95/5).
- FP dan FN berbeda biaya (deteksi penyakit, fraud).
- Multikelas dengan distribusi sangat tidak rata.

## Pitfalls
- Jangan pernah laporkan akurasi saja di kasus imbalanced.
- "Akurasi 99%" tanpa konteks distribusi kelas = tanda merah.

## Kaitan
- → [Presisi](10-presisi.md), [Recall](11-recall.md), [F1-Score](12-f1-score.md)
- → [Confusion Matrix](08-confusion-matrix.md)

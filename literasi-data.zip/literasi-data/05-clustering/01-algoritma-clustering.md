# Algoritma Clustering

**Kategori:** Clustering | **Level:** Dasar

## Ringkasan
Clustering membagi data menjadi kelompok (cluster) sehingga item dalam satu cluster mirip satu sama lain dan berbeda dengan item di cluster lain — tanpa label training. Termasuk dalam unsupervised learning.

## Jenis Algoritma

| Kategori | Algoritma | Karakteristik |
|----------|-----------|---------------|
| Partitional | K-Means, K-Medoids | Tentukan K di awal |
| Hierarchical | Agglomerative, Divisive | Dendogram, tidak perlu K |
| Density-based | DBSCAN, OPTICS | Menangani outlier, cluster bentuk bebas |
| Model-based | Gaussian Mixture | Probabilistik |
| Fuzzy | Fuzzy C-Means | Satu titik bisa milik banyak cluster |

## Langkah Umum
1. Pilih fitur yang relevan.
2. Scaling (penting!).
3. Pilih algoritma & parameter (K, eps, min_samples).
4. Jalankan clustering.
5. Evaluasi internal (Silhouette, DB, CH) dan eksternal (Rand Index jika ada label).
6. Interpretasi cluster: beri nama, profiling, visualisasi.

## Studi Kasus PANDORA
Segmentasi 40 OPD berdasar pola kehadiran bulanan:
- Fitur: rata-rata kehadiran, SD keterlambatan, rasio alpa, rasio izin.
- K-Means dengan K=3 menghasilkan:
  - **Cluster A:** kehadiran tinggi, disiplin tinggi (OPD "teladan").
  - **Cluster B:** kehadiran sedang, volatil.
  - **Cluster C:** kehadiran rendah, perlu intervensi.

Dashboard PANDORA dapat menandai cluster C untuk tindak lanjut prioritas.

## Pitfalls
- Clustering tanpa scaling = hasil bias ke fitur berskala besar.
- K-Means asumsi cluster sferis; bentuk kompleks butuh DBSCAN atau Spectral.
- Cluster tanpa interpretasi bisnis = hanya angka tanpa guna.

## Kaitan
- → [K-Means](02-kmeans.md)
- → [Performance Clustering](03-performance-clustering.md)

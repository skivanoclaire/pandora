# Davies-Bouldin Index

**Kategori:** Clustering | **Level:** Menengah

## Ringkasan
Davies-Bouldin Index (DBI) mengukur rata-rata "kemiripan" maksimum antar cluster, di mana kemiripan adalah rasio dispersi dalam-cluster terhadap jarak antar-cluster. **Semakin rendah, semakin baik** (cluster lebih terpisah).

## Rumus

$$\text{DBI} = \frac{1}{k} \sum_{i=1}^{k} \max_{j \neq i} R_{ij}$$

di mana $R_{ij} = \frac{S_i + S_j}{d(c_i, c_j)}$,
- $S_i$ = rata-rata jarak titik di cluster $i$ ke centroid $c_i$ (dispersi).
- $d(c_i, c_j)$ = jarak antar centroid.

## Interpretasi
- DBI rendah → cluster ketat dan saling berjauhan.
- DBI tinggi → cluster overlap atau menyebar.
- Tidak ada batas atas teoritis, tapi DBI < 1 umumnya bagus.

## Memilih K
Pilih K yang menghasilkan DBI minimum.

## Studi Kasus PANDORA
Clustering OPD dengan beberapa K:

| K | DBI |
|---|-----|
| 2 | 1.20 |
| 3 | **0.72** |
| 4 | 0.95 |
| 5 | 1.10 |

K=3 punya DBI terendah → pilih K=3 (konsisten dengan CH dan Silhouette).

```python
from sklearn.metrics import davies_bouldin_score
dbi = davies_bouldin_score(X, labels)
```

## Pitfalls
- DBI bias terhadap cluster bola-bola (sferis).
- Tidak handle cluster dengan kepadatan beda baik.
- Skalabilitas: O(k²·n) — bisa lambat untuk K besar.

## Kaitan
- → [Calinski-Harabasz Index](05-calinski-harabasz.md)
- → [Silhouette Score](07-silhouette.md)
- → [Performance Clustering](03-performance-clustering.md)

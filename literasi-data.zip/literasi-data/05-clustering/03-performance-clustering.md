# Performance Clustering

**Kategori:** Clustering | **Level:** Menengah

## Ringkasan
Berbeda dengan klasifikasi, clustering tanpa label sebenarnya membuat evaluasi lebih tricky. Kita pakai dua jenis metrik: **internal** (tidak butuh label) dan **eksternal** (butuh ground truth).

## Metrik Internal (tanpa label)
Mengukur kualitas berdasar kohesi (titik dekat centroidnya) dan separasi (cluster saling berjauhan).

- **Silhouette Score** — (-1 ke 1), makin tinggi makin baik.
- **Davies-Bouldin Index** — makin rendah makin baik.
- **Calinski-Harabasz Index** — makin tinggi makin baik.
- **WCSS/Inertia** — makin rendah makin baik (tapi selalu menurun dengan K).

## Metrik Eksternal (butuh label)
Hanya bisa dipakai jika kita punya ground truth (misal cluster validasi manual).

- **Rand Index & Adjusted Rand Index (ARI)** — kesesuaian dengan label asli.
- **Mutual Information, Adjusted MI, Normalized MI.**
- **Homogeneity, Completeness, V-Measure.**

## Memilih Metrik
| Situasi | Metrik |
|---------|--------|
| Tuning K | Silhouette / DB / CH |
| Bandingkan dengan label pakar | ARI / NMI |
| Explorasi awal | Silhouette |

## Studi Kasus PANDORA
Cluster 40 OPD dengan K-Means, K=3:
- Silhouette = 0.58 (baik).
- Davies-Bouldin = 0.72 (baik, rendah).
- Calinski-Harabasz = 142 (relatif tinggi untuk data ini).

Dibandingkan K=4: Silhouette turun ke 0.42. Pilih K=3.

## Pitfalls
- Metrik internal favor cluster bola-bola → misleading untuk DBSCAN.
- Tanpa label, tetap butuh domain expert untuk validasi interpretasi.

## Kaitan
- → [Silhouette Score](07-silhouette.md), [Davies-Bouldin](06-davies-bouldin.md), [Calinski-Harabasz](05-calinski-harabasz.md), [Rand Index](04-rand-index.md)

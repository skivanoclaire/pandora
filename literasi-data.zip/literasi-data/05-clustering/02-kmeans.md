# K-Means Clustering

**Kategori:** Clustering | **Level:** Dasar

## Ringkasan
K-Means adalah algoritma clustering paling populer. Membagi data ke K cluster dengan meminimalkan jarak titik ke centroid cluster (within-cluster sum of squares, WCSS).

## Algoritma (Lloyd's)
1. Pilih K secara acak sebagai centroid awal.
2. **Assign:** tiap titik ditempatkan di cluster centroid terdekat.
3. **Update:** centroid dihitung ulang sebagai mean titik-titik dalam cluster.
4. Ulangi 2-3 hingga konvergen (centroid tidak berubah signifikan).

## Fungsi Objektif
$$J = \sum_{i=1}^{K} \sum_{x \in C_i} \|x - \mu_i\|^2$$

## Memilih K
- **Elbow method:** plot WCSS vs K, cari "siku".
- **Silhouette score:** maksimalkan rata-rata silhouette.
- **Gap statistic.**
- **Domain knowledge.**

## Studi Kasus PANDORA
Cluster 6.475 pegawai berdasar 4 fitur (rata_telat, jumlah_alpa, jumlah_izin, durasi_kerja):

```python
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

X_scaled = StandardScaler().fit_transform(X)
km = KMeans(n_clusters=3, n_init=10, random_state=42)
labels = km.fit_predict(X_scaled)
```

Profiling hasil:
- Cluster 0 (n=4500): pegawai disiplin standar.
- Cluster 1 (n=1700): pegawai sering izin tapi datang tepat waktu.
- Cluster 2 (n=275): kandidat alpa kronis → prioritas pembinaan.

## Pitfalls
- Centroid awal acak → hasil bisa berbeda. Gunakan `n_init>1` atau `k-means++`.
- Sensitif outlier (centroid mean tertarik).
- Hanya cocok cluster berbentuk bola, ukuran serupa.
- K harus ditentukan sebelumnya.

## Kaitan
- → [Algoritma Clustering](01-algoritma-clustering.md)
- → [Silhouette Score](07-silhouette.md)
- → [Davies-Bouldin Index](06-davies-bouldin.md)

# Silhouette Score

**Kategori:** Clustering | **Level:** Menengah

## Ringkasan
Silhouette Score mengukur seberapa mirip suatu titik dengan cluster-nya sendiri dibandingkan cluster terdekat lainnya. Rentang -1 hingga 1. **Mendekati 1 = sangat baik**, 0 = di perbatasan, negatif = mungkin salah cluster.

## Rumus
Untuk setiap titik $i$:
$$s(i) = \frac{b(i) - a(i)}{\max(a(i), b(i))}$$

- $a(i)$ = rata-rata jarak titik $i$ ke titik lain dalam cluster yang sama.
- $b(i)$ = rata-rata jarak titik $i$ ke titik di cluster terdekat lainnya.

Silhouette Score keseluruhan = rata-rata $s(i)$ untuk semua titik.

## Interpretasi
| Nilai | Arti |
|-------|------|
| 0.71 – 1.00 | Struktur cluster sangat kuat |
| 0.51 – 0.70 | Struktur cluster wajar |
| 0.26 – 0.50 | Struktur cluster lemah |
| < 0.25 | Tidak ada struktur cluster bermakna |

## Memilih K
Plot Silhouette vs K, pilih K dengan score tertinggi.

## Visualisasi Silhouette
Silhouette plot per cluster sangat berguna:
- Cluster yang baik: bar tinggi & rata.
- Cluster buruk: banyak bar pendek atau negatif.

## Studi Kasus PANDORA
Clustering OPD:

| K | Silhouette |
|---|-----------|
| 2 | 0.45 |
| 3 | **0.58** |
| 4 | 0.42 |
| 5 | 0.38 |

K=3 dipilih.

```python
from sklearn.metrics import silhouette_score, silhouette_samples
score = silhouette_score(X, labels)
sample_silhouettes = silhouette_samples(X, labels)  # untuk plot
```

## Pitfalls
- Komputasi O(n²) — lambat untuk dataset besar; sample dahulu.
- Bias terhadap cluster konveks.
- Negatif silhouette untuk titik tertentu = sinyal titik tersebut salah klaster.

## Kaitan
- → [Performance Clustering](03-performance-clustering.md)
- → [K-Means](02-kmeans.md)
- → [Davies-Bouldin Index](06-davies-bouldin.md)

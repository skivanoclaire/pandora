# Calinski-Harabasz Index

**Kategori:** Clustering | **Level:** Menengah

## Ringkasan
Calinski-Harabasz Index (CH, atau Variance Ratio Criterion) mengukur rasio dispersi antar-cluster terhadap dispersi dalam-cluster. **Semakin tinggi, semakin baik** — menandakan cluster yang ketat secara internal dan saling berjauhan.

## Rumus
$$\text{CH} = \frac{\text{tr}(B_k)}{\text{tr}(W_k)} \cdot \frac{n - k}{k - 1}$$

- $B_k$ = matriks dispersi antar-cluster (between).
- $W_k$ = matriks dispersi dalam-cluster (within).
- $n$ = total observasi, $k$ = jumlah cluster.

## Intuisi
Pembilang: cluster makin berjauhan, makin tinggi.
Penyebut: titik dalam cluster makin mampat, makin rendah.
Faktor $(n-k)/(k-1)$ mengoreksi jumlah cluster.

## Menggunakan CH
- Jalankan clustering dengan beberapa nilai K (misal 2-10).
- Plot CH vs K.
- Pilih K dengan CH tertinggi (atau titik "lonjakan" jelas).

## Studi Kasus PANDORA
Clustering pegawai dengan K-Means, bandingkan K:

| K | CH |
|---|-----|
| 2 | 820 |
| 3 | **1420** |
| 4 | 1280 |
| 5 | 1100 |

K=3 memberi CH tertinggi → pilih K=3.

```python
from sklearn.metrics import calinski_harabasz_score
ch = calinski_harabasz_score(X, labels)
```

## Pitfalls
- Cenderung favor cluster banyak karena komputasi based on variance.
- Kurang reliabel pada cluster non-sferis.
- Sensitif terhadap scaling.

## Kaitan
- → [Performance Clustering](03-performance-clustering.md)
- → [Davies-Bouldin Index](06-davies-bouldin.md)
- → [Silhouette Score](07-silhouette.md)

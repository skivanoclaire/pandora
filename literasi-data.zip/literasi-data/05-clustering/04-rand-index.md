# Rand Index

**Kategori:** Clustering | **Level:** Menengah

## Ringkasan
Rand Index (RI) mengukur kesesuaian antara dua partisi data — biasanya antara hasil clustering algoritma dengan ground truth (label) yang diketahui. Nilai 0-1: 1 = sempurna, 0 = acak.

## Rumus
$$\text{RI} = \frac{a + b}{\binom{n}{2}}$$

Di mana:
- $a$ = jumlah pasangan titik yang BERADA di cluster yang sama di keduanya.
- $b$ = jumlah pasangan titik yang TERPISAH di kedua partisi.
- $\binom{n}{2}$ = total pasangan titik.

## Adjusted Rand Index (ARI)
Masalah RI: bahkan clustering acak bisa dapat nilai tinggi. ARI mengoreksi dengan mengurangi expected value:

$$\text{ARI} = \frac{\text{RI} - E[\text{RI}]}{1 - E[\text{RI}]}$$

Rentang: -1 hingga 1. ARI = 0 = acak. ARI = 1 = sempurna.

## Kapan Pakai?
- Kita punya label ground truth (misal cluster yang disusun pakar domain).
- Membandingkan dua hasil clustering berbeda.

## Studi Kasus PANDORA
Pakar HR mengelompokkan 40 OPD menjadi 3 kategori kedisiplinan (manual). K-Means juga menghasilkan 3 cluster otomatis.

- RI antara label pakar vs K-Means = 0.82.
- ARI = 0.68 → sangat baik (sangat mirip, lebih dari sekadar kebetulan).

```python
from sklearn.metrics import rand_score, adjusted_rand_score
ari = adjusted_rand_score(y_true, y_pred)
```

## Pitfalls
- RI bias pada K besar (cluster kecil-kecil).
- Butuh label; tidak berguna pada pure unsupervised task.
- Kalau ARI negatif, hasil lebih buruk daripada acak.

## Kaitan
- → [Performance Clustering](03-performance-clustering.md)
- → [Silhouette Score](07-silhouette.md) (alternatif tanpa label)

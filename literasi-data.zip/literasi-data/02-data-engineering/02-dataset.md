# Dataset

**Kategori:** Data Engineering | **Level:** Dasar

## Ringkasan
Dataset adalah kumpulan data yang dikemas untuk satu tujuan analisis. Biasanya dalam bentuk tabel: baris = observasi (instance), kolom = variabel (feature).

## Penjelasan
Dataset bisa berupa:
- **CSV/Excel** — tabular klasik.
- **Image folder + label** — dataset visi.
- **Korpus teks** — dokumen + label sentimen.
- **Time series** — observasi terurut waktu.

Setiap dataset yang baik memiliki:
- Skema kolom yang jelas (nama, tipe, satuan).
- Dokumentasi sumber & metode pengumpulan.
- Lisensi (terutama jika dataset publik).
- Pemisahan train/validation/test untuk ML.

## Studi Kasus PANDORA
Dataset yang dapat dirakit dari PANDORA untuk pelatihan model:

| Kolom | Tipe | Contoh |
|-------|------|--------|
| nip | string | "19870615..." |
| opd | kategori | "Dinas Kominfo" |
| jabatan | kategori | "Staf" |
| umur | numerik | 38 |
| menit_terlambat | numerik | 5 |
| hari | kategori | "Senin" |
| status_telat | label | 1 |

Total: 6.475 baris × N hari kerja → puluhan ribu instance.

## Split Data ML
- **Train (70%)** — untuk melatih model.
- **Validation (15%)** — tuning hyperparameter.
- **Test (15%)** — evaluasi akhir, hanya dipakai sekali.

## Pitfalls
- Bocornya test set ke train (data leakage) → akurasi palsu.
- Imbalanced dataset (misal 95% hadir, 5% tidak) butuh penanganan khusus.

## Kaitan
- → [Dataset Public](09-dataset-public.md)
- → [Data Quality](04-data-quality.md)

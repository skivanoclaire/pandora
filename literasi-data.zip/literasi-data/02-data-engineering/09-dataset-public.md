# Dataset Public

**Kategori:** Data Engineering | **Level:** Dasar

## Ringkasan
Dataset publik adalah kumpulan data yang dirilis terbuka untuk riset, pembelajaran, dan benchmarking. Mereka berperan besar dalam perkembangan data science karena memungkinkan reproduksi dan perbandingan model.

## Sumber Populer

### Umum
- **Kaggle** (kaggle.com/datasets) — ribuan dataset lintas domain.
- **UCI ML Repository** — klasik untuk machine learning.
- **Google Dataset Search** — mesin pencari dataset.
- **Hugging Face Datasets** — terutama NLP/CV.

### Pemerintah Indonesia
- **Satu Data Indonesia** (data.go.id) — portal resmi.
- **BPS** (bps.go.id) — statistik sosial, ekonomi, demografi.
- **BMKG** — data cuaca & iklim.
- **data.kaltaraprov.go.id** — jika sudah tersedia portal provinsi.

### Domain Spesifik
- **MNIST/CIFAR/ImageNet** — computer vision.
- **IMDB/SST** — sentiment analysis.
- **Titanic/Iris** — dataset pedagogis klasik.

## Kriteria Dataset Berkualitas
- Lisensi jelas (CC-BY, MIT, Open Data Commons).
- Dokumentasi & data dictionary.
- Provenance (dari mana datanya?).
- Versi & changelog.

## Studi Kasus PANDORA
Untuk memperkaya analisis PANDORA, kita bisa menggabungkan:
- **BMKG** → data cuaca harian Kaltara → cek korelasi cuaca ↔ keterlambatan.
- **BPS** → data hari libur nasional → normalisasi hari kerja.
- **Satu Data Kaltara** → data demografi Kaltara untuk konteks.

## Pitfalls
- Data publik ≠ boleh dipakai sembarangan. Selalu cek lisensi.
- Kualitas bervariasi; banyak dataset Kaggle yang tidak terverifikasi.

## Kaitan
- → [Database](10-database.md)
- → [Dataset](02-dataset.md)

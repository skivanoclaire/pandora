# Data Augmentation

**Kategori:** Data Engineering | **Level:** Menengah

## Ringkasan
Data augmentation adalah teknik menambah variasi data training secara sintetik agar model lebih general dan tahan terhadap variasi nyata. Paling umum dipakai pada citra dan teks.

## Teknik Berdasar Jenis Data

### Citra (Computer Vision)
- Rotasi, flip horizontal/vertikal, crop acak.
- Perubahan brightness, contrast, saturation.
- Penambahan noise, blur, cutout, mixup.

### Teks (NLP)
- Sinonim replacement (ganti kata dengan sinonim).
- Back-translation (terjemah ke bahasa lain lalu kembali).
- Random insertion/deletion/swap kata.

### Tabular
- SMOTE (Synthetic Minority Oversampling) untuk kelas minoritas.
- Penambahan noise gaussian pada fitur numerik.

## Manfaat
- Mengatasi dataset kecil.
- Mengurangi overfitting.
- Menyeimbangkan kelas pada data imbalanced.

## Studi Kasus PANDORA
Jika DKISP membangun face recognition untuk presensi:
- 100 foto per pegawai sangat sedikit.
- Augmentasi: rotasi ±15°, brightness ±20%, sedikit blur → 100 foto menjadi 1000 efektif.
- Hasilnya: model lebih tahan pencahayaan kantor pagi/sore.

Untuk data tabular keterlambatan, jika hanya 5% pegawai yang masuk kelas "alpa kronis", SMOTE bisa membuat sintetik tambahan agar model klasifikasi tidak bias.

## Pitfalls
- Augmentasi yang tidak realistis (misal flip vertikal wajah) merusak performance.
- SMOTE bisa membuat sample sintetik yang tidak masuk akal pada fitur kategorik.

## Kaitan
- → [Computer Vision](../07-data-tak-terstruktur/05-computer-vision.md)
- → [Data Preprocessing](05-data-preprocessing.md)

# Data Transformation

**Kategori:** Data Engineering | **Level:** Dasar

## Ringkasan
Data transformation adalah proses mengubah bentuk, skala, atau representasi data agar sesuai kebutuhan algoritma. Penting karena banyak algoritma (KNN, SVM, neural network) sensitif terhadap skala.

## Teknik Utama

### Scaling / Normalisasi
- **Min-Max scaling** → rentang [0,1]: $x' = (x - x_{min})/(x_{max} - x_{min})$
- **Standardization (Z-score)** → mean 0, SD 1: $x' = (x - \mu)/\sigma$
- **Robust scaling** → pakai median & IQR, tahan outlier.

### Encoding Kategorik
- **Label encoding** → A/B/C jadi 0/1/2 (hati-hati, jangan di nominal!).
- **One-hot encoding** → setiap kategori jadi kolom biner.
- **Target encoding** → ganti kategori dengan mean target di grup tersebut.

### Transformasi Matematis
- **Log transform** → skewness tinggi: `log(x+1)`.
- **Box-Cox / Yeo-Johnson** → paksa ke normal-ish.
- **Binning** → kontinu jadi ordinal bucket.

## Studi Kasus PANDORA
Fitur mentah → setelah transformasi:

| Fitur | Transformasi | Alasan |
|-------|--------------|--------|
| umur | standardization | jangkauan 22-60, untuk KNN |
| opd | one-hot | nominal, >30 kategori |
| golongan | label encoding (hati-hati) | ordinal, urutan bermakna |
| menit_terlambat | log(x+1) | distribusi sangat miring |
| hari | one-hot | nominal |

## Pitfalls
- Scaling dilakukan SETELAH split train/test, fit di train saja.
- Label encoding pada nominal membuat model mengira ada urutan.
- Terlalu banyak one-hot (high cardinality) → dimensi meledak.

## Kaitan
- → [Data Preprocessing](05-data-preprocessing.md)
- → [Feature Engineering](11-feature-engineering.md)

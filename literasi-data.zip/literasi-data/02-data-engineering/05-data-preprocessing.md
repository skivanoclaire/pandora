# Data Preprocessing

**Kategori:** Data Engineering | **Level:** Dasar

## Ringkasan
Data preprocessing adalah serangkaian langkah membersihkan dan menyiapkan data mentah agar siap dipakai algoritma. Dalam proyek nyata, fase ini menyita 60-80% waktu.

## Langkah Umum

1. **Data cleaning** — tangani missing values, outlier, duplikat.
2. **Data integration** — gabungkan data dari banyak sumber.
3. **Data transformation** — normalisasi, encoding, scaling.
4. **Data reduction** — PCA, sampling, feature selection.
5. **Data discretization** — ubah kontinu jadi bin kategorik.

## Teknik Missing Values
- **Drop row** — jika missing sedikit.
- **Drop column** — jika missing dominan.
- **Imputation** — isi dengan mean/median/modus/KNN/regresi.
- **Flag** — tambah kolom "is_missing" sebagai sinyal.

## Teknik Outlier
- Deteksi: IQR (>Q3+1.5×IQR), Z-score (|z|>3), isolation forest.
- Tangani: buang, winsorize, atau keep jika memang valid.

## Studi Kasus PANDORA
Log presensi April 2026:
```python
df = pd.read_csv('presensi.csv')
df.drop_duplicates(['nip','tanggal'], inplace=True)  # dedup
df['checkin'] = pd.to_datetime(df['checkin'], errors='coerce')  # parse
df['menit_terlambat'].fillna(0, inplace=True)  # asumsi tidak ada data = tidak terlambat
df = df[df['menit_terlambat'] < 480]  # outlier > 8 jam dihapus
```

## Pitfalls
- Preprocess train+test bersama-sama = data leakage. Selalu fit di train, apply di test.
- Mengisi NA sebelum split data = leakage pada statistik (mean).

## Kaitan
- → [Data Quality](04-data-quality.md)
- → [Data Transformation](08-data-transformation.md)
- → [Data Reduction](06-data-reduction.md)

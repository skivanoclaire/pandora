# Database

**Kategori:** Data Engineering | **Level:** Dasar

## Ringkasan
Database adalah sistem terstruktur untuk menyimpan dan mengelola data sehingga dapat dibaca, ditulis, diperbarui, dan dihapus secara efisien dan konsisten. Dua kategori utama: relasional (SQL) dan non-relasional (NoSQL).

## Jenis Database

### Relasional (SQL)
- MySQL, PostgreSQL, MariaDB, SQL Server, Oracle.
- Data disimpan dalam tabel dengan skema tetap.
- Bahasa query: SQL.
- Cocok untuk data transaksional dengan relasi kuat.

### NoSQL
- **Document**: MongoDB (JSON-like).
- **Key-value**: Redis.
- **Columnar**: Cassandra, HBase.
- **Graph**: Neo4j.
- Cocok untuk data semi-terstruktur, volume besar, skala horizontal.

### Warehousing & Analytics
- BigQuery, Snowflake, Redshift — OLAP, optimized untuk agregasi besar.

## SQL Dasar
```sql
SELECT opd, AVG(menit_terlambat) AS rata_telat
FROM presensi
WHERE tanggal BETWEEN '2026-04-01' AND '2026-04-18'
GROUP BY opd
HAVING AVG(menit_terlambat) > 10
ORDER BY rata_telat DESC;
```

## Studi Kasus PANDORA
PANDORA kemungkinan besar memakai database relasional untuk menyimpan:
- `pegawai` (master 6.475 baris)
- `opd` (master)
- `presensi` (jutaan baris log)
- `sinkronisasi_log` (riwayat sync)

Relasi: `presensi.nip → pegawai.nip`, `pegawai.opd_id → opd.id`.

## Pitfalls
- NoSQL bukan "pasti lebih cepat". Pilih sesuai pola query.
- Query tanpa index pada tabel besar = lambat.
- Normalisasi berlebihan mempersulit analisis; denormalisasi berlebihan menyulitkan konsistensi.

## Kaitan
- → [Data](01-data.md)
- → [Dataset](02-dataset.md)

# Feature Engineering

**Kategori:** Data Engineering | **Level:** Menengah

## Ringkasan
Feature engineering adalah seni dan sains menciptakan fitur baru dari data mentah agar model dapat belajar pola lebih baik. Sering kali lebih berdampak pada performa daripada pemilihan algoritma.

## Teknik Umum

### Dari Tanggal
- Ekstrak: hari dalam minggu, minggu ke-, bulan, apakah weekend, hari ke-N sejak libur.

### Agregasi Time-window
- Mean keterlambatan 7 hari terakhir.
- Max durasi kerja bulan lalu.
- Frekuensi alpa 30 hari.

### Interaksi
- `golongan × umur` → mengindikasikan senioritas.
- `jabatan × opd` → kombinasi peran unik.

### Rasio
- `hari_hadir / hari_kerja` → tingkat kehadiran.

### Polynomial
- $x^2, x \cdot y$ untuk regresi non-linier.

## Studi Kasus PANDORA
Fitur mentah: `nip, tanggal, checkin, opd`.

Fitur rekayasa untuk model prediksi keterlambatan:
- `telat_7hari_terakhir` (rolling mean)
- `setelah_libur` (boolean)
- `hari_kerja_ke_n_bulan`
- `cuaca_harian` (join dari BMKG)
- `rata_telat_opd` (target encoding)

Model yang pakai fitur ini biasanya jauh lebih akurat daripada model yang pakai data mentah saja.

## Pitfalls
- Target encoding tanpa cross-validation → data leakage.
- Fitur masa depan bocor ke masa lalu (look-ahead bias) pada time series.
- Fitur terlalu banyak → curse of dimensionality.

## Kaitan
- → [Data Transformation](08-data-transformation.md)
- → [Data Reduction](06-data-reduction.md)

# Tipe Data

**Kategori:** Data Engineering | **Level:** Dasar

## Ringkasan
Tipe data menentukan operasi apa yang valid pada sebuah variabel. Salah memilih tipe = salah memilih algoritma. Klasifikasi paling umum: numerik (kontinu, diskrit) dan kategorik (nominal, ordinal).

## Klasifikasi

### Numerik
- **Kontinu** — bisa bernilai tak hingga dalam suatu rentang. Contoh: durasi kerja (8.25 jam).
- **Diskrit** — bilangan bulat yang dihitung. Contoh: jumlah hari hadir (22).

### Kategorik
- **Nominal** — kategori tanpa urutan. Contoh: nama OPD, jenis kelamin.
- **Ordinal** — kategori dengan urutan tapi jarak antar kategori tidak setara. Contoh: golongan kepegawaian (II/a < III/a < IV/a).

### Lain
- **Tanggal/Waktu** — perlu parsing khusus.
- **Teks bebas** — perlu NLP preprocessing.
- **Boolean** — true/false.

## Skala Pengukuran (Stevens)
| Skala | Operasi sah | Contoh |
|-------|-------------|--------|
| Nominal | =, ≠ | OPD |
| Ordinal | =, <, > | Golongan |
| Interval | + dan − | Suhu Celsius |
| Rasio | ×, ÷ | Berat, gaji |

## Studi Kasus PANDORA

| Kolom | Tipe | Skala |
|-------|------|-------|
| nip | string (ID) | nominal |
| nama_opd | kategori | nominal |
| golongan | kategori | ordinal |
| menit_terlambat | numerik kontinu | rasio |
| jumlah_alpa | numerik diskrit | rasio |
| tanggal | datetime | interval |

## Pitfalls
- Mengkode "golongan" sebagai angka 1-4 dan memakainya di regresi linier tanpa berpikir = salah, karena golongan ordinal, jarak tidak setara.
- Tanggal yang diparse sebagai string membuat agregasi berdasar bulan jadi mustahil.

## Kaitan
- → [Data Transformation](08-data-transformation.md)
- → [Statistika Deskriptif](../01-fondasi/03-statistika-deskriptif.md)

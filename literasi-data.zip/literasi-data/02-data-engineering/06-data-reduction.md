# Data Reduction

**Kategori:** Data Engineering | **Level:** Menengah

## Ringkasan
Data reduction adalah teknik mengurangi volume data tanpa kehilangan informasi signifikan, agar komputasi lebih cepat dan model tidak overfit. Dua jalur: mengurangi **baris** (sampling) dan mengurangi **kolom** (feature selection / dimensionality reduction).

## Teknik Utama

### Pengurangan dimensi kolom
- **Feature Selection** — filter (korelasi, chi-square), wrapper (recursive elimination), embedded (Lasso).
- **Feature Extraction** — PCA (Principal Component Analysis), LDA, t-SNE, UMAP.

### Pengurangan jumlah baris
- **Random sampling** — ambil subset acak.
- **Stratified sampling** — mempertahankan proporsi kelas.
- **Aggregation** — rangkum dari harian ke bulanan.

### Kompresi nilai
- **Binning/Discretization** — ubah usia kontinu menjadi bucket (<25, 25-40, >40).

## PCA Ringkas
PCA mencari sumbu baru yang menangkap variansi maksimum. Beberapa komponen pertama biasanya menjelaskan >90% informasi.

## Studi Kasus PANDORA
Jika kita punya 50 fitur presensi per pegawai (per bulan, per shift, per lokasi), modelnya lambat dan berisiko overfit. Solusi:
- **Feature Selection:** hitung korelasi dengan target → simpan 15 fitur terkuat.
- **Aggregation:** alih-alih log per jam, pakai agregat per hari.
- **PCA:** reduksi 50 fitur jadi 5 komponen utama untuk visualisasi cluster OPD.

## Pitfalls
- PCA menghilangkan interpretability (sumbu tidak punya nama).
- Sampling tanpa stratifikasi bisa membuat kelas minoritas hilang.

## Kaitan
- → [Data Preprocessing](05-data-preprocessing.md)
- → [Feature Engineering](11-feature-engineering.md)

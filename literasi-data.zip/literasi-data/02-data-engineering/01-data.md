# Data

**Kategori:** Data Engineering | **Level:** Dasar

## Ringkasan
Data adalah fakta mentah yang dapat direkam, disimpan, dan diolah. Bisa berupa angka, teks, gambar, audio, video, sinyal sensor, atau apapun yang dapat di-encode secara digital.

## Penjelasan
Data tanpa konteks hanyalah simbol. Misal angka `08:05` bisa berarti waktu, harga, kode produk — bergantung skema. Karena itu data selalu hadir dalam **struktur** (kolom, label, tipe).

Berdasarkan struktur:
- **Terstruktur** — tersusun dalam tabel relasional (database PANDORA).
- **Semi-terstruktur** — punya tag/penanda tapi tidak kaku (JSON log presensi).
- **Tak terstruktur** — bebas (foto wajah pegawai, dokumen scan SK).

Berdasarkan sumber:
- **Internal:** sistem PANDORA, SIMPEG, e-Layanan DKISP.
- **Eksternal:** BMKG (cuaca), BPS (statistik nasional), API publik.

## Studi Kasus PANDORA
Satu baris log presensi adalah "data":
```
{nip: "19870615...", checkin: "08:05", lokasi: "kantor", tanggal: "2026-04-18"}
```

Ribuan baris seperti ini selama bertahun-tahun = "data presensi" yang dapat dianalisis menjadi informasi (lihat DIKW).

## Pitfalls
- Data ≠ kebenaran. Data bisa salah, terlambat, terduplikasi.
- Data tanpa metadata (tipe, satuan, sumber) cepat membingungkan.

## Kaitan
- → [Dataset](02-dataset.md)
- → [Tipe Data](03-tipe-data.md)
- → [Data, Informasi, Pengetahuan](../01-fondasi/02-data-informasi-pengetahuan.md)

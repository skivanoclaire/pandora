# Data Quality

**Kategori:** Data Engineering | **Level:** Dasar

## Ringkasan
Kualitas data adalah sejauh mana data memenuhi kebutuhan penggunanya. Enam dimensi klasik: accuracy, completeness, consistency, timeliness, validity, uniqueness.

## Enam Dimensi

| Dimensi | Pertanyaan | Contoh masalah di PANDORA |
|---------|-----------|---------------------------|
| Accuracy | Apakah nilainya benar? | Lokasi checkin palsu karena GPS spoofing |
| Completeness | Apakah tidak ada yang kosong? | Kolom `jabatan` kosong untuk 120 pegawai |
| Consistency | Apakah tidak bertentangan antar sumber? | Nama OPD di PANDORA beda dengan SIMPEG |
| Timeliness | Apakah diupdate tepat waktu? | Sync presensi tertunda 51 menit |
| Validity | Apakah sesuai aturan/format? | NIP berisi huruf |
| Uniqueness | Apakah tidak terduplikasi? | Satu pegawai double checkin |

## Mengukur Kualitas
```python
df.isna().sum()                       # completeness
df['nip'].duplicated().sum()          # uniqueness  
df['nip'].str.match(r'^\d{18}$').mean()  # validity
```

## Studi Kasus PANDORA
Pesan di dashboard: "Belum ada data kehadiran untuk Sabtu, 18 April 2026" — ini masalah **completeness** (ada 8 OPD < 80%) dan **timeliness** (sync tertunda).

## Pitfalls
- Menganggap "data dari sistem" = pasti benar. Tidak.
- Menghapus semua baris NA → kehilangan informasi berharga (kenapa NA?).
- Mengisi NA dengan mean tanpa berpikir → bias.

## Kaitan
- → [Data Preprocessing](05-data-preprocessing.md)
- → [Data Transformation](08-data-transformation.md)

## Referensi
- Wang & Strong (1996), Beyond Accuracy: What Data Quality Means to Data Consumers.

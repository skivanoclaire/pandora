# Data, Informasi, dan Pengetahuan

**Kategori:** Fondasi | **Level:** Dasar

## Ringkasan
Piramida DIKW (Data–Information–Knowledge–Wisdom) adalah kerangka klasik untuk memahami bagaimana fakta mentah berubah menjadi keputusan yang berguna. Data → Informasi → Pengetahuan → Kearifan.

## Penjelasan
**Data** adalah fakta mentah (angka, teks, simbol) tanpa konteks. Misal: `08:05`. **Informasi** adalah data yang sudah diorganisir dan diberi konteks — "Pegawai A masuk pukul 08:05 tanggal 18 April". **Pengetahuan** muncul dari pola dalam banyak informasi — "Pegawai A sering terlambat di hari Senin". **Kearifan** adalah kemampuan memakai pengetahuan untuk membuat keputusan bijaksana — "Beri pelatihan manajemen waktu khusus pada pegawai yang pola Seninnya merah".

## Hirarki DIKW

```
       ▲  Kearifan (Wisdom)   → Keputusan
       │  Pengetahuan         → Pola
       │  Informasi           → Konteks
       │  Data                → Fakta mentah
```

## Studi Kasus PANDORA
| Tingkat | Contoh di PANDORA |
|---------|-------------------|
| Data | `checkin=08:05, nip=19870101...` |
| Informasi | "Pegawai X OPD Dinas Kominfo masuk jam 08:05 pada 18 April 2026" |
| Pengetahuan | "30% pegawai Dinas Kominfo rutin terlambat di awal pekan" |
| Kearifan | "Pindahkan briefing pagi ke siang agar pegawai tidak terburu-buru" |

## Pitfalls
- Banyak sistem berhenti di level "informasi" (dashboard) tanpa mengekstrak pengetahuan.
- Kearifan butuh domain expert, tidak otomatis dari data.

## Kaitan
- → [Data](../02-data-engineering/01-data.md)
- → [Statistika Deskriptif](03-statistika-deskriptif.md)

## Referensi
- Ackoff, R. L. (1989). From Data to Wisdom. *Journal of Applied Systems Analysis*.

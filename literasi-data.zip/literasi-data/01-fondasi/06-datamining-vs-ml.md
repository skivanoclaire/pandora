# Data Mining vs Machine Learning

**Kategori:** Fondasi | **Level:** Dasar

## Ringkasan
Data Mining adalah proses menemukan pola yang sebelumnya tidak diketahui dari kumpulan data besar. Machine Learning adalah teknik di mana algoritma "belajar" dari data untuk membuat prediksi/keputusan. Data Mining sering memakai algoritma ML, tapi tujuannya berbeda: discovery vs prediction.

## Penjelasan
**Data Mining** menjawab "pola apa yang ada dalam data ini?". Outputnya berupa aturan, asosiasi, atau cluster yang dapat ditafsirkan manusia. Contoh klasik: market basket analysis (Apriori).

**Machine Learning** menjawab "berdasarkan data masa lalu, apa yang akan terjadi?". Outputnya berupa model yang dapat memprediksi pada data baru. Contoh: spam filter, prediksi harga rumah.

## Perbandingan

| Aspek | Data Mining | Machine Learning |
|-------|-------------|------------------|
| Tujuan utama | Menemukan pola tersembunyi | Membangun model prediktif |
| Output | Insight, aturan, cluster | Model yang bisa diquery |
| Pendekatan | Eksploratoris | Konvergen ke fungsi |
| Manusia di loop | Sangat dibutuhkan untuk interpretasi | Bisa otomatis |
| Contoh | Apriori, K-Means | KNN, JST, Random Forest |

## Studi Kasus PANDORA
- **Data Mining:** Menjalankan Apriori pada log presensi → menemukan aturan "Jika pegawai terlambat di Senin DAN setelah hari libur, maka 70% akan terlambat lagi besoknya".
- **Machine Learning:** Melatih model klasifikasi yang memprediksi apakah seorang pegawai berisiko absen besok berdasarkan riwayat 30 hari terakhir.

## Pitfalls
- Sering tertukar — di praktik, banyak pipeline pakai keduanya berurutan.
- Data Mining tanpa validasi statistik = penemuan pola palsu (spurious patterns).

## Kaitan
- → [Algoritma Klasifikasi](../03-klasifikasi/01-algoritma-klasifikasi.md)
- → [Apriori](../06-association-rule/02-apriori.md)

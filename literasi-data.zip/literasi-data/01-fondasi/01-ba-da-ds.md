# Business Analytics, Data Analytics, dan Data Science

**Kategori:** Fondasi | **Level:** Dasar

## Ringkasan
Ketiga istilah sering dipakai bergantian, tetapi memiliki fokus dan ruang lingkup berbeda. Singkatnya: Data Analytics fokus pada "apa yang terjadi", Business Analytics menjawab "apa yang harus dilakukan", dan Data Science mencakup keduanya plus pengembangan model prediktif dan prescriptif berbasis machine learning.

## Penjelasan
**Data Analytics** berfokus pada eksplorasi data historis untuk memahami pola — melibatkan SQL, Excel, dan visualisasi. **Business Analytics** adalah aplikasi Data Analytics dalam konteks keputusan bisnis; outputnya berupa rekomendasi, KPI, dan forecasting. **Data Science** adalah disiplin yang lebih luas, menggabungkan statistik, pemrograman, dan machine learning untuk membangun model yang memprediksi atau mengoptimalkan keputusan, biasanya pada data yang jauh lebih besar dan kompleks.

## Perbandingan

| Aspek | Data Analytics | Business Analytics | Data Science |
|-------|----------------|--------------------|--------------| 
| Fokus | Apa yang terjadi | Apa yang sebaiknya dilakukan | Memprediksi & mengoptimalkan |
| Alat | SQL, Excel, BI | BI, Statistik | Python/R, ML, Deep Learning |
| Output | Dashboard, laporan | Rekomendasi strategis | Model prediktif |
| Jenis analisis | Deskriptif | Deskriptif + Preskriptif | Deskriptif + Prediktif + Preskriptif |

## Studi Kasus PANDORA
- **Data Analytics:** Membuat dashboard tren kehadiran 7 hari (seperti yang sudah tampil di PANDORA).
- **Business Analytics:** Merekomendasikan OPD mana yang perlu intervensi karena kehadiran < 80%.
- **Data Science:** Membangun model prediksi risiko keterlambatan pegawai berdasar riwayat presensi, cuaca, dan hari kerja.

## Kaitan
- → [Data Science vs AI](05-ds-vs-ai.md)
- → [Data Mining vs ML](06-datamining-vs-ml.md)

## Referensi
- Provost & Fawcett, *Data Science for Business*, O'Reilly.

# Data Science vs Artificial Intelligence

**Kategori:** Fondasi | **Level:** Dasar

## Ringkasan
Data Science dan AI sering disamakan tetapi memiliki cakupan berbeda. Data Science fokus pada ekstraksi wawasan dari data (sering berakhir pada laporan atau model prediksi). AI fokus pada membangun sistem yang berperilaku cerdas (bisa tanpa data historis, misal rule-based atau search algorithm).

## Penjelasan
**Data Science** adalah disiplin lintas bidang (statistik + programming + domain knowledge) yang tujuannya menjawab pertanyaan bisnis/penelitian dengan data. Outputnya bisa berupa dashboard, insight, atau model prediktif.

**Artificial Intelligence** adalah cabang ilmu komputer yang tujuannya menciptakan agen yang dapat memahami, belajar, dan bertindak. AI mencakup: machine learning (sub-bagian yang belajar dari data), reasoning, planning, NLP, computer vision, robotics, hingga sistem pakar.

## Diagram Hubungan

```
┌─────────────── Artificial Intelligence ───────────────┐
│                                                        │
│   ┌──────── Machine Learning ─────┐                    │
│   │                               │                    │
│   │   ┌── Deep Learning ──┐       │   Rule-based AI    │
│   │   │                   │       │   Expert System    │
│   │   └───────────────────┘       │   Search / Planning│
│   │                               │                    │
│   └───────────────────────────────┘                    │
└────────────────────────────────────────────────────────┘
     ▲ tumpang tindih dengan ▲
┌──────────── Data Science ──────────────┐
│  Statistik · EDA · Visualisasi · ML    │
└────────────────────────────────────────┘
```

## Studi Kasus PANDORA
- **Data Science:** menganalisis data kehadiran 6.475 pegawai untuk mencari pola keterlambatan.
- **AI:** sistem face recognition di mesin presensi fisik (teknik computer vision); chatbot yang menjawab pertanyaan pegawai tentang cuti.

Keduanya bisa bertemu: model Data Science yang dideploy di mesin presensi = sistem AI.

## Pitfalls
- "Pakai AI" tanpa data berkualitas = rentan bias dan gagal.
- Tidak semua AI butuh machine learning (rule-based masih sangat relevan).

## Kaitan
- → [Data Mining vs ML](06-datamining-vs-ml.md)
- → [Deep Learning](../03-klasifikasi/07-deep-learning.md)

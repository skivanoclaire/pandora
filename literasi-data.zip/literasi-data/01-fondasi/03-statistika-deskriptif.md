# Statistika Deskriptif

**Kategori:** Fondasi | **Level:** Dasar

## Ringkasan
Statistika deskriptif adalah metode merangkum dan menyajikan karakteristik data tanpa menarik kesimpulan tentang populasi yang lebih luas. Tujuannya: memahami "apa yang terjadi" pada data.

## Penjelasan
Tiga pilar utama:

1. **Ukuran pemusatan** — di mana pusat data berada (mean, median, modus).
2. **Ukuran penyebaran** — seberapa lebar data tersebar (range, variance, standar deviasi, IQR).
3. **Ukuran posisi & bentuk** — kuartil, persentil, skewness, kurtosis.

Visualisasi pendukung: histogram, boxplot, tabel frekuensi.

## Studi Kasus PANDORA
Dari 6.475 pegawai aktif, eksplorasi cepat:
- **Mean jam masuk** harian → menentukan "jam normal" kehadiran (misal 07:48).
- **Median durasi kerja** → 8 jam 12 menit; tidak terpengaruh pegawai yang lembur ekstrem.
- **Modus hari keterlambatan** → biasanya Senin.
- **Standar deviasi keterlambatan** → mengukur konsistensi: SD kecil = pegawai disiplin.
- **Boxplot per OPD** → cepat melihat OPD mana yang punya banyak outlier keterlambatan.

```python
df.groupby('opd')['menit_terlambat'].describe()
```

## Pitfalls
- Mean sangat sensitif terhadap outlier; gunakan median jika distribusi miring.
- Jangan bandingkan SD antar variabel berskala beda — pakai *coefficient of variation* (CV = SD/mean).
- Statistika deskriptif TIDAK boleh dipakai untuk menyimpulkan populasi — itu tugas statistika inferensial.

## Kaitan
- → [Mean, Modus, Standar Deviasi](04-mean-modus-sd.md)
- → [Data Quality](../02-data-engineering/04-data-quality.md)

## Referensi
- Walpole & Myers, *Probability & Statistics for Engineers*.
- `pandas.DataFrame.describe()` untuk eksplorasi cepat.

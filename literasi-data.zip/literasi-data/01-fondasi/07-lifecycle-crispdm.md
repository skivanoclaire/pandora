# Siklus Hidup Proyek Data (CRISP-DM)

**Kategori:** Fondasi | **Level:** Dasar

## Ringkasan
CRISP-DM (Cross-Industry Standard Process for Data Mining) adalah kerangka 6 fase iteratif untuk mengelola proyek data science dari pemahaman bisnis hingga deployment. Standar de facto industri sejak 1999.

## Enam Fase

1. **Business Understanding** — Apa pertanyaan bisnis yang dijawab?
2. **Data Understanding** — Eksplorasi awal data, kualitas, sumber.
3. **Data Preparation** — Pembersihan, transformasi, feature engineering.
4. **Modeling** — Pemilihan dan training algoritma.
5. **Evaluation** — Apakah model menjawab pertanyaan bisnis?
6. **Deployment** — Integrasi ke sistem produksi.

```
Business → Data → Data
Understand  Understand  Prep
    ↑                    ↓
Deployment ← Evaluation ← Modeling
```

Panah dapat balik kapan saja — proses iteratif, bukan linier.

## Studi Kasus PANDORA
Proyek "Prediksi Risiko Keterlambatan Pegawai":
1. **BU:** Tujuan = mengurangi keterlambatan kronis 20% dalam 6 bulan.
2. **DU:** Eksplorasi log presensi 1 tahun, cek missing values, distribusi per OPD.
3. **DP:** Bersihkan checkpoint duplikat, tambah fitur "hari setelah libur".
4. **Modeling:** Train Naive Bayes & C4.5 → bandingkan.
5. **Evaluation:** F1-score ≥ 0.75 → model layak.
6. **Deployment:** Tampilkan flag "berisiko" di dashboard atasan langsung.

## Pitfalls
- Lompat ke modeling tanpa Business Understanding = solusi tanpa masalah.
- Data Preparation biasanya menyita 60-80% waktu — jangan diremehkan.
- Tanpa fase Deployment, model menumpuk di laptop data scientist.

## Kaitan
- → [Data Preprocessing](../02-data-engineering/05-data-preprocessing.md)
- → [Performance Klasifikasi](../03-klasifikasi/08-performance-klasifikasi.md)

## Referensi
- Chapman et al. (2000), *CRISP-DM 1.0 Step-by-step Guide*.

# Mean, Modus, dan Standar Deviasi

**Kategori:** Fondasi | **Level:** Dasar

## Ringkasan
Tiga statistik paling sering dilaporkan. Mean adalah rata-rata aritmetik, modus adalah nilai paling sering muncul, standar deviasi mengukur seberapa jauh data menyebar dari mean.

## Rumus

**Mean (rata-rata):**
$$\bar{x} = \frac{1}{n}\sum_{i=1}^{n} x_i$$

**Modus:** nilai dengan frekuensi tertinggi (bisa tidak ada, satu, atau lebih — unimodal/bimodal/multimodal).

**Variance:** $\sigma^2 = \frac{1}{n}\sum(x_i - \bar{x})^2$
**Standar Deviasi (SD):** $\sigma = \sqrt{\sigma^2}$

Untuk sampel, pembagi diganti $n-1$ (koreksi Bessel).

## Interpretasi
- **Mean tinggi + SD kecil** → data konsisten di sekitar rata-rata.
- **Mean tinggi + SD besar** → rata-rata tinggi tapi variasi lebar.
- **Aturan empiris (distribusi normal):** ±1σ menangkap 68% data, ±2σ 95%, ±3σ 99.7%.

## Studi Kasus PANDORA
Menit keterlambatan pegawai OPD Dinas Kominfo bulan Maret 2026:
`[0, 5, 2, 10, 0, 0, 8, 3, 0, 0, 120]`

- Mean = 13.5 menit → *tertarik* oleh outlier 120.
- Median = 2 menit → lebih wakil kondisi nyata.
- Modus = 0 → mayoritas pegawai tidak terlambat.
- SD = 34.7 → sangat lebar karena outlier.

**Kesimpulan:** Jangan hanya laporkan mean. Kombinasikan dengan median dan SD agar tidak menyesatkan.

## Pitfalls
- Mean + outlier ekstrem = angka yang menyesatkan.
- SD tidak berarti jika distribusi sangat tidak simetris.
- Modus bisa tidak unik; hati-hati saat melaporkan.

## Kaitan
- → [Statistika Deskriptif](03-statistika-deskriptif.md)
- → [Data Quality](../02-data-engineering/04-data-quality.md)

## Referensi
- `numpy.mean`, `numpy.std`, `scipy.stats.mode`.

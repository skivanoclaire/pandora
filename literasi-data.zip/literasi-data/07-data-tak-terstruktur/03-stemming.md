# Stemming

**Kategori:** Data Tak Terstruktur | **Level:** Dasar

## Ringkasan
Stemming mereduksi kata ke bentuk dasar/akarnya dengan menghapus afiks (awalan, akhiran, sisipan). Tujuan: mengurangi redundansi — "memuaskan", "kepuasan", "puas" jadi "puas".

## Stemming vs Lemmatization

| Aspek | Stemming | Lemmatization |
|-------|----------|---------------|
| Metode | Aturan pemotongan afiks | Kamus & morfologi |
| Hasil | Bisa bukan kata valid | Kata dasar valid |
| Kecepatan | Cepat | Lebih lambat |
| Akurasi | Kasar | Lebih presisi |

## Teknik Stemmer Indonesia
- **Nazief-Adriani** — algoritma klasik bahasa Indonesia, pakai kamus + aturan.
- **Arifin-Setiono** — variant dengan perbaikan.
- **Enhanced Confix Stripping (ECS)** — modifikasi Nazief dengan banyak aturan.

## Implementasi Sastrawi
```python
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
stemmer = StemmerFactory().create_stemmer()

print(stemmer.stem("memuaskan"))     # puas
print(stemmer.stem("kepuasan"))      # puas
print(stemmer.stem("pemberitahuan")) # tahu
```

## Studi Kasus PANDORA / DKISP
Keluhan warga: "pelayanannya mengecewakan, petugasnya kurang ramah".

Setelah tokenisasi + stemming (Sastrawi):
`["layan", "kecewa", "tugas", "kurang", "ramah"]`

Kata "pelayanan" dan "layanan" keduanya jadi "layan" → konsolidasi fitur untuk klasifikasi sentimen.

## Pitfalls
- **Over-stemming:** dua kata dengan makna beda disamakan ("beruang"=bear/ada uang → "uang"? hati-hati).
- **Under-stemming:** dua bentuk kata sama tidak disamakan.
- Stemmer Inggris tidak cocok untuk Indonesia.
- Untuk tugas presisi tinggi (legal, medis), lebih baik lemmatization.

## Kaitan
- → [Tokenisasi](02-tokenisasi.md), [TF-IDF](04-tf-idf.md)
- → [NLP](01-nlp.md)

## Referensi
- Sastrawi (github.com/sastrawi/sastrawi).
- Nazief & Adriani (1996), Confix Stripping: Approach to Stemming Algorithm for Bahasa Indonesia.

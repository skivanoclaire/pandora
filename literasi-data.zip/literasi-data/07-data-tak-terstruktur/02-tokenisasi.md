# Tokenisasi

**Kategori:** Data Tak Terstruktur | **Level:** Dasar

## Ringkasan
Tokenisasi adalah proses memecah teks menjadi unit-unit bermakna (token) — bisa kata, karakter, atau sub-kata. Langkah pertama hampir di semua pipeline NLP.

## Jenis Tokenisasi

### Word-level
Pisah per spasi/tanda baca.
```
"Pelayanan DKISP sangat memuaskan."
→ ["Pelayanan", "DKISP", "sangat", "memuaskan", "."]
```

### Character-level
Pisah per karakter. Berguna untuk bahasa tanpa spasi (Cina, Jepang) atau data sangat noisy.

### Subword (BPE, WordPiece, SentencePiece)
Pecah kata menjadi unit lebih kecil. Dipakai di BERT, GPT, dll.
```
"memuaskan" → ["me", "##muas", "##kan"]
```
Keunggulan: menangani out-of-vocabulary (OOV).

## Tantangan Bahasa Indonesia
- Bentuk dasar + afiks: "memuaskan" = me + puas + kan.
- Kontraksi, singkatan ("yg", "dgn", "bpk").
- Nama orang/tempat dengan spasi.

## Tools
- **NLTK** `word_tokenize` — dasar.
- **spaCy** — cepat, support ID (model id_core_news_sm).
- **Sastrawi** — khusus Bahasa Indonesia (tokenizer + stemmer).
- **HuggingFace Tokenizers** — subword.

## Studi Kasus PANDORA
Tokenisasi keluhan: "Tolong perbaiki koneksi wifi di kantor DKISP":
- Word: ["Tolong", "perbaiki", "koneksi", "wifi", "di", "kantor", "DKISP"]
- Setelah stopword removal: ["perbaiki", "koneksi", "wifi", "kantor", "DKISP"]
- Siap untuk vektorisasi TF-IDF.

```python
from nltk.tokenize import word_tokenize
tokens = word_tokenize("Tolong perbaiki koneksi wifi.")
```

## Pitfalls
- Simple split pada spasi gagal pada emoticon, URL, hashtag.
- Jangan tokenisasi terlebih dahulu kalau mau preserve punctuation untuk sentiment (tanda seru penting).
- Encoding UTF-8 harus benar; karakter ID bisa rusak.

## Kaitan
- → [Stemming](03-stemming.md), [TF-IDF](04-tf-idf.md)
- → [NLP](01-nlp.md)

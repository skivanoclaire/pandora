# Natural Language Processing (NLP)

**Kategori:** Data Tak Terstruktur | **Level:** Menengah

## Ringkasan
NLP adalah cabang AI yang membuat komputer memahami, menafsirkan, dan menghasilkan bahasa manusia. Mencakup mulai dari preprocessing teks dasar hingga model bahasa raksasa (LLM).

## Tugas-tugas Umum NLP

| Tugas | Deskripsi | Contoh |
|-------|-----------|--------|
| Klasifikasi teks | Beri label dokumen | Sentimen positif/negatif |
| Named Entity Recognition (NER) | Ekstrak entitas | Nama orang, OPD, tanggal |
| Sentiment Analysis | Polaritas opini | Keluhan vs apresiasi |
| Topic Modeling | Tema dominan | LDA, BERTopic |
| Machine Translation | Terjemahan | ID ↔ EN |
| Question Answering | Tanya jawab | Chatbot |
| Summarization | Ringkasan | Abstraksi laporan panjang |

## Pipeline NLP Klasik
1. **Cleaning** — buang HTML, simbol aneh.
2. **Lowercasing.**
3. **Tokenisasi** — pecah jadi kata.
4. **Stopword removal** — buang "yang", "di", "ini".
5. **Stemming/Lemmatization** — normalisasi bentuk dasar.
6. **Vektorisasi** — TF-IDF, BoW, embeddings (Word2Vec, BERT).
7. **Modeling** — klasik (Naive Bayes, SVM) atau neural (LSTM, Transformer).

## Studi Kasus PANDORA / DKISP
Modul portal e-Layanan DKISP menerima ribuan keluhan masyarakat per bulan. NLP dapat membantu:
- **Klasifikasi otomatis** keluhan ke OPD penanggung jawab.
- **Sentiment analysis** untuk prioritas (sangat negatif → urgent).
- **Topic modeling** untuk laporan periodik (apa keluhan terbanyak bulan ini?).
- **NER** mengekstrak lokasi/nama lembaga dari teks bebas.

## Pitfalls
- Bahasa Indonesia memiliki morfologi rumit (afiksasi); tool English tidak langsung pakai.
- Kasus khusus: bahasa daerah, slang, singkatan.
- Bias dan privasi dalam data teks.

## Kaitan
- → [Tokenisasi](02-tokenisasi.md), [Stemming](03-stemming.md), [TF-IDF](04-tf-idf.md)
- → [Naive Bayes](../03-klasifikasi/04-naive-bayes.md)

# Histogram Warna

**Kategori:** Data Tak Terstruktur | **Level:** Dasar

## Ringkasan
Histogram warna adalah distribusi frekuensi intensitas piksel dalam gambar. Salah satu fitur gambar paling sederhana dan efektif untuk klasifikasi berbasis warna (misal klasifikasi bunga, makanan, scene).

## Konsep
Untuk gambar grayscale 8-bit (0-255), histogram adalah array 256-bin yang menghitung berapa piksel punya intensitas tertentu.

Untuk gambar RGB: tiga histogram terpisah (R, G, B) atau satu histogram 3D (bin per kombinasi).

## Langkah Perhitungan
1. Konversi ke ruang warna yang relevan (RGB, HSV, LAB).
2. Tentukan jumlah bin (misal 8, 16, 64 per channel).
3. Hitung kemunculan piksel per bin.
4. Normalisasi (bagi dengan total piksel) agar independen ukuran gambar.

## Manfaat
- Invarian terhadap rotasi dan translasi.
- Komputasi sangat cepat.
- Intuitif dan dapat dibaca.

## Studi Kasus PANDORA
Deteksi apakah foto presensi diambil di lingkungan kantor (indoor, pencahayaan tertentu) atau di luar (outdoor, cerah):
- Foto indoor kantor: histogram cenderung condong ke nilai tengah (lampu neon hangat).
- Foto outdoor: histogram lebih lebar, puncak di area terang.
- Simpan histogram sebagai feature vector 48-dim (16 bin × 3 channel).

```python
import cv2
hist = cv2.calcHist([img], [0,1,2], None, [8,8,8], [0,256]*3)
hist = cv2.normalize(hist, hist).flatten()
```

## Pitfalls
- Tidak menangkap informasi spasial ("di mana" warnanya berada).
- Sensitif terhadap pencahayaan.
- Dua gambar berbeda bisa punya histogram identik.

## Kaitan
- → [Moment Warna](08-moment-warna.md), [GLCM](09-glcm.md)
- → [Fitur Gambar](06-fitur-gambar.md)

# Fitur Gambar

**Kategori:** Data Tak Terstruktur | **Level:** Menengah

## Ringkasan
Fitur gambar (image features) adalah representasi numerik yang mendeskripsikan karakteristik gambar (warna, tekstur, bentuk) sehingga dapat diolah algoritma ML klasik. Di era deep learning, fitur sering dipelajari otomatis, tapi fitur hand-crafted masih berguna untuk dataset kecil atau interpretabilitas.

## Kategori Fitur

### Fitur Warna
- **Histogram warna** — distribusi intensitas per channel.
- **Moment warna** — statistik (mean, SD, skewness) per channel.
- **Color Coherence Vector.**

### Fitur Tekstur
- **GLCM (Gray-Level Co-occurrence Matrix)** — statistik pasangan piksel.
- **LBP (Local Binary Patterns)** — pola piksel lokal.
- **Gabor filters** — filter berarah.
- **Wavelet.**

### Fitur Bentuk
- **Edge detection** (Canny, Sobel).
- **Hu Moments** — invarian translasi/rotasi.
- **Contour descriptors.**

### Fitur Lokal (Keypoint)
- **SIFT / SURF / ORB** — fitur invarian skala & rotasi.
- **HOG (Histogram of Oriented Gradients)** — untuk deteksi pedestrian.

### Fitur dari Deep Network
- Aktivasi dari CNN pretrained (ResNet, VGG) sebagai feature vector.

## Studi Kasus PANDORA
Memisahkan foto presensi wajah asli dari foto spoofing (foto dari HP):
- Histogram warna → foto spoofing cenderung beda distribusi.
- GLCM → tekstur layar HP beda dari kulit.
- Edge density → bingkai layar muncul.
- Kombinasi fitur → klasifier Random Forest deteksi spoofing.

## Pitfalls
- Fitur hand-crafted sensitif pencahayaan/rotasi; lakukan normalisasi.
- Tidak ada satu set fitur universal; pilih sesuai masalah.
- Deep learning sering mengungguli hand-crafted jika data banyak.

## Kaitan
- → [Histogram](07-histogram.md), [Moment Warna](08-moment-warna.md), [GLCM](09-glcm.md)
- → [Computer Vision](05-computer-vision.md)

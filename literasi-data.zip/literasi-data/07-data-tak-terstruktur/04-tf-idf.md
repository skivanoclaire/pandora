# TF-IDF

**Kategori:** Data Tak Terstruktur | **Level:** Menengah

## Ringkasan
TF-IDF (Term Frequency – Inverse Document Frequency) adalah skema pembobotan yang menunjukkan pentingnya sebuah kata dalam satu dokumen relatif terhadap seluruh korpus. Kata yang sering muncul di satu dokumen tapi jarang di dokumen lain = penting.

## Rumus

**Term Frequency (TF):**
$$\text{TF}(t, d) = \frac{\#\text{kemunculan } t \text{ di } d}{\#\text{total kata di } d}$$

**Inverse Document Frequency (IDF):**
$$\text{IDF}(t) = \log \frac{N}{\#\text{dokumen yang memuat } t}$$

**TF-IDF:**
$$\text{TF-IDF}(t, d) = \text{TF}(t, d) \cdot \text{IDF}(t)$$

## Intuisi
- **TF tinggi** → kata sering muncul di dokumen → mungkin penting.
- **IDF tinggi** → kata jarang di korpus → spesifik.
- **TF-IDF tinggi** = kata sering di dokumen INI, tapi jarang di dokumen LAIN → pembeda.

Kata-kata umum ("yang", "dan") akan punya IDF rendah → otomatis tertekan.

## Studi Kasus PANDORA / DKISP
Korpus: 1000 keluhan warga. Dokumen: satu keluhan tunggal.

Kata "wifi" muncul 5× dalam keluhan tertentu, muncul di 50 dari 1000 dokumen:
- TF = 5/30 = 0.167 (jika dokumen 30 kata).
- IDF = log(1000/50) = log(20) ≈ 3.
- TF-IDF = 0.50.

Kata "dan" muncul 2× di dokumen, muncul di 950 dari 1000 dokumen:
- IDF = log(1000/950) ≈ 0.05.
- TF-IDF ≈ 0.003 (sangat kecil, bagus).

```python
from sklearn.feature_extraction.text import TfidfVectorizer
vec = TfidfVectorizer(max_features=5000)
X = vec.fit_transform(corpus)
```

## Aplikasi
- Klasifikasi teks (dipasangkan dengan Naive Bayes, SVM).
- Information retrieval (cosine similarity antar dokumen).
- Ekstraksi keyword otomatis.

## Pitfalls
- Tidak menangkap urutan/konteks kata (bag-of-words).
- Vokabulari besar → matrix sangat sparse.
- Untuk pemahaman semantik, beralih ke embeddings (Word2Vec, BERT).

## Kaitan
- → [Tokenisasi](02-tokenisasi.md), [Stemming](03-stemming.md)
- → [Naive Bayes](../03-klasifikasi/04-naive-bayes.md)
- → [NLP](01-nlp.md)

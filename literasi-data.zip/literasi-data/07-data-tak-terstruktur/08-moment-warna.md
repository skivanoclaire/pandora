# Moment Warna

**Kategori:** Data Tak Terstruktur | **Level:** Menengah

## Ringkasan
Moment warna adalah ukuran statistik (mean, standar deviasi, skewness) dari distribusi nilai piksel per channel warna. Cara kompak mendeskripsikan warna gambar dalam 9 angka saja (3 statistik × 3 channel RGB) — alternatif lebih ringkas dari histogram.

## Tiga Moment Utama

**Moment 1 (Mean):** rata-rata intensitas channel.
$$M_i = \frac{1}{N} \sum_{j=1}^{N} p_{ij}$$

**Moment 2 (Standar Deviasi):** sebaran intensitas.
$$\sigma_i = \sqrt{\frac{1}{N} \sum (p_{ij} - M_i)^2}$$

**Moment 3 (Skewness):** kemiringan distribusi.
$$s_i = \sqrt[3]{\frac{1}{N} \sum (p_{ij} - M_i)^3}$$

Untuk gambar RGB → 9 fitur total.

## Manfaat
- Sangat ringkas.
- Cepat dihitung.
- Robust terhadap perubahan resolusi.

## Studi Kasus PANDORA
Klasifikasi cepat foto presensi: outdoor / indoor / spoofing (foto layar):

| Kategori | Mean R | SD R | Skew R |
|----------|--------|------|--------|
| Outdoor cerah | 180 | 45 | -0.8 |
| Indoor kantor | 120 | 30 | 0.2 |
| Foto layar HP | 95 | 25 | 0.6 |

Pakai 9 fitur ini sebagai input ke KNN/Random Forest → klasifier ringan & cepat.

```python
import numpy as np
def color_moments(img):
    feats = []
    for ch in cv2.split(img):  # B, G, R
        feats.extend([
            np.mean(ch),
            np.std(ch),
            np.cbrt(np.mean((ch - np.mean(ch))**3))
        ])
    return np.array(feats)  # 9 fitur
```

## Pitfalls
- Hanya menangkap informasi statistik global → kehilangan detail.
- Skewness peka outlier piksel (sangat terang/gelap).
- Dua gambar dengan distribusi sama tapi pola beda dianggap sama.

## Kaitan
- → [Histogram](07-histogram.md), [GLCM](09-glcm.md)
- → [Fitur Gambar](06-fitur-gambar.md)

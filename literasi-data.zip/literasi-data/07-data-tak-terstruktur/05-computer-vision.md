# Computer Vision

**Kategori:** Data Tak Terstruktur | **Level:** Menengah

## Ringkasan
Computer Vision (CV) adalah cabang AI yang membuat komputer "melihat" dan memahami gambar/video. Mulai dari klasifikasi sederhana hingga deteksi objek, segmentasi, hingga generatif.

## Tugas Utama CV

| Tugas | Deskripsi | Contoh |
|-------|-----------|--------|
| Image Classification | Label keseluruhan gambar | "kucing" vs "anjing" |
| Object Detection | Kotak + label | YOLO, Faster R-CNN |
| Segmentation | Pixel-level label | U-Net, Mask R-CNN |
| Face Recognition | Identifikasi wajah | Unlocking, attendance |
| OCR | Ekstrak teks dari gambar | Scan KTP |
| Pose Estimation | Postur tubuh | Fitness apps |
| Generative | Buat gambar baru | GAN, Stable Diffusion |

## Representasi Gambar
Gambar digital = matriks piksel. Grayscale: 1 channel (0-255). RGB: 3 channel. HSV, LAB: ruang warna alternatif.

Ukuran gambar 100×100 RGB = 100 × 100 × 3 = 30.000 nilai piksel.

## Pendekatan

### Klasik (Feature Engineering)
Ekstrak fitur buatan tangan (histogram, GLCM, HOG, SIFT) → klasik ML.

### Deep Learning
CNN belajar fitur otomatis dari data. State-of-the-art di hampir semua tugas CV.

## Studi Kasus PANDORA
- **Face recognition** untuk presensi on-site DKISP — mengganti fingerprint. Model CNN dilatih dari foto pegawai + data augmentation.
- **OCR** pada scan surat masuk untuk ekstraksi metadata otomatis.
- **Deteksi anomali** pada foto presensi (orang yang sama muncul di lokasi berbeda dalam waktu dekat).

## Pitfalls
- Privacy — data wajah sangat sensitif; patuhi UU PDP.
- Bias — model bisa berperforma buruk pada subgroup tertentu.
- Butuh banyak data berlabel; gunakan transfer learning (pretrained ImageNet).

## Kaitan
- → [Fitur Gambar](06-fitur-gambar.md), [Histogram](07-histogram.md), [Moment Warna](08-moment-warna.md), [GLCM](09-glcm.md)
- → [Deep Learning](../03-klasifikasi/06-deep-learning.md)

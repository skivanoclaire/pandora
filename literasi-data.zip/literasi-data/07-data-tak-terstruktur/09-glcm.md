# GLCM (Gray-Level Co-occurrence Matrix)

**Kategori:** Data Tak Terstruktur | **Level:** Lanjut

## Ringkasan
GLCM adalah matriks yang mendeskripsikan frekuensi pasangan piksel bertetangga dengan intensitas tertentu. Dari GLCM diturunkan fitur tekstur (Haralick features) yang sangat berguna untuk klasifikasi berbasis pola permukaan.

## Konsep
GLCM ukuran G × G (G = jumlah level keabu-abuan, misal 256 atau lebih sering direduksi ke 8/16) di mana entri (i,j) = berapa kali piksel bernilai i berpasangan dengan piksel bernilai j dengan offset tertentu (jarak, sudut).

Parameter:
- **Jarak d** — umumnya 1 piksel.
- **Sudut θ** — 0°, 45°, 90°, 135°.

## Fitur Haralick Utama

**Contrast** — variasi intensitas lokal:
$$\sum (i-j)^2 \cdot P(i,j)$$

**Correlation** — hubungan linier antar piksel.

**Energy (Angular Second Moment)** — keseragaman tekstur:
$$\sum P(i,j)^2$$

**Homogeneity (Inverse Difference Moment)** — kedekatan elemen ke diagonal:
$$\sum \frac{P(i,j)}{1 + (i-j)^2}$$

**Entropy** — keacakan tekstur.

## Studi Kasus PANDORA
Pada deteksi spoofing foto presensi:
- Kulit asli punya tekstur mikro (pori, rambut halus) → entropy tinggi, homogeneity rendah.
- Foto layar HP halus tanpa tekstur mikro → homogeneity tinggi, entropy rendah.

Ekstraksi GLCM (4 sudut × 5 fitur) = 20 fitur untuk klasifier.

```python
from skimage.feature import graycomatrix, graycoprops
glcm = graycomatrix(gray_img, distances=[1],
                    angles=[0, np.pi/4, np.pi/2, 3*np.pi/4],
                    levels=16, symmetric=True, normed=True)
contrast = graycoprops(glcm, 'contrast')
homogeneity = graycoprops(glcm, 'homogeneity')
```

## Pitfalls
- Gambar harus diubah ke grayscale & didiskritisasi levelnya (quantization).
- Ukuran G besar → matriks sparse, komputasi berat.
- Sensitif terhadap rotasi; mitigasi dengan merata-ratakan banyak sudut.

## Kaitan
- → [Histogram](07-histogram.md), [Moment Warna](08-moment-warna.md)
- → [Fitur Gambar](06-fitur-gambar.md)
- → [Computer Vision](05-computer-vision.md)

## Referensi
- Haralick, Shanmugam, Dinstein (1973), *Textural Features for Image Classification*.

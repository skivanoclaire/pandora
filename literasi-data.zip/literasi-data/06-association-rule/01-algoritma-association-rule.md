# Algoritma Association Rule

**Kategori:** Association Rule | **Level:** Menengah

## Ringkasan
Association Rule Mining (ARM) menemukan aturan if-then yang menggambarkan co-occurrence antar item dalam data transaksi. Contoh klasik: "Jika pembeli membeli roti dan mentega, maka 80% juga membeli susu".

## Komponen Rule
Aturan berbentuk $X \Rightarrow Y$, di mana X dan Y adalah itemset disjoint.

### Tiga Metrik Utama

**Support** — seberapa sering itemset muncul:
$$\text{Support}(X) = \frac{\#(X)}{N}$$

**Confidence** — seberapa sering X diikuti Y:
$$\text{Confidence}(X \Rightarrow Y) = \frac{\text{Support}(X \cup Y)}{\text{Support}(X)}$$

**Lift** — seberapa banyak Y lebih sering muncul bersama X dibanding acak:
$$\text{Lift}(X \Rightarrow Y) = \frac{\text{Confidence}(X \Rightarrow Y)}{\text{Support}(Y)}$$

- Lift > 1 → positif (co-occur > acak).
- Lift = 1 → independen.
- Lift < 1 → negatif (saling menolak).

## Algoritma Populer
- **Apriori** — klasik, mudah, tapi lambat untuk dataset besar.
- **FP-Growth** — lebih cepat, tanpa generate kandidat.
- **Eclat** — pakai representasi vertikal.

## Studi Kasus PANDORA
Analisis pola "transaksi" = hari kerja, "item" = kejadian:
- Item: `terlambat`, `setelah_libur`, `hujan`, `hari_Senin`, `OPD_tertentu`, `izin_tak_masuk`.

Aturan yang mungkin ditemukan:
- `{Senin, setelah_libur} ⇒ {terlambat}` dengan support=15%, confidence=72%, lift=2.1.

Interpretasi: hari Senin setelah libur panjang, 72% dari pegawai yang tersampling terlambat — 2.1x lebih sering daripada baseline.

## Pitfalls
- Support tinggi saja tidak berarti menarik (mungkin trivial).
- Confidence tinggi bisa menyesatkan jika Y memang sangat umum; cek lift juga.
- Banyak rule dihasilkan → perlu filter berdasar business interest.

## Kaitan
- → [Apriori](02-apriori.md)
- → [Data Mining vs ML](../01-fondasi/06-datamining-vs-ml.md)

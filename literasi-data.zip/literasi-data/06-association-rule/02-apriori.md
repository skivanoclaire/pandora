# Algoritma Apriori

**Kategori:** Association Rule | **Level:** Menengah

## Ringkasan
Apriori (Agrawal & Srikant, 1994) adalah algoritma klasik untuk menemukan frequent itemsets dan membangun association rules. Prinsip inti: jika suatu itemset tidak frequent, semua supersetnya juga tidak frequent (downward closure).

## Langkah Algoritma

1. Scan database → hitung support tiap item (L1 = items frequent).
2. Generate kandidat itemset ukuran k dari L(k-1).
3. Scan database → hitung support kandidat.
4. Buang kandidat dengan support < min_support → dapatkan L(k).
5. Ulangi sampai tidak ada L(k) baru.
6. Dari itemsets frequent, bangun rules yang memenuhi min_confidence.

## Prinsip Apriori
"If an itemset is frequent, then all of its subsets must also be frequent."
Ini memungkinkan **pruning**: tidak perlu cek kandidat yang salah satu subset-nya sudah tidak frequent.

## Studi Kasus PANDORA
Transaksi = log presensi harian, item = atribut kejadian:

```
Hari 1: {Senin, Hujan, terlambat_OPD-A, terlambat_OPD-B}
Hari 2: {Selasa, Cerah, tepat_waktu_OPD-A}
Hari 3: {Senin, Hujan, terlambat_OPD-A, izin_massal}
...
```

Setting: min_support=5%, min_confidence=60%.

Rule yang mungkin muncul:
- `{Hujan, Senin} ⇒ {terlambat_OPD-A}` — support 8%, confidence 75%, lift 1.8.
- `{setelah_libur} ⇒ {terlambat_massal}` — support 12%, confidence 70%.

Implementasi Python:
```python
from mlxtend.frequent_patterns import apriori, association_rules
freq = apriori(df_onehot, min_support=0.05, use_colnames=True)
rules = association_rules(freq, metric='confidence', min_threshold=0.6)
```

## Pitfalls
- Sangat lambat pada dataset besar dengan banyak item → pakai FP-Growth.
- min_support terlalu kecil → rule banyak dan kebanyakan noise.
- min_support terlalu besar → kehilangan rule menarik.

## Kaitan
- → [Algoritma Association Rule](01-algoritma-association-rule.md)
- → [Data Mining vs ML](../01-fondasi/06-datamining-vs-ml.md)

## Referensi
- Agrawal & Srikant (1994), *Fast Algorithms for Mining Association Rules*.

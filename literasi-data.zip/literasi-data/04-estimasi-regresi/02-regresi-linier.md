# Regresi Linier

**Kategori:** Estimasi & Regresi | **Level:** Dasar

## Ringkasan
Regresi linier sederhana memodelkan hubungan antara satu variabel independen (X) dan satu variabel dependen (y) dengan garis lurus. Fondasi yang harus dipahami sebelum model lebih kompleks.

## Model
$$y = \beta_0 + \beta_1 x + \epsilon$$

- $\beta_0$ = intersep (nilai y saat x=0).
- $\beta_1$ = slope (perubahan y per unit perubahan x).
- $\epsilon$ = error.

## Estimasi Parameter (OLS)
Ordinary Least Squares mencari $\beta_0, \beta_1$ yang meminimalkan jumlah kuadrat error:

$$\beta_1 = \frac{\sum (x_i - \bar{x})(y_i - \bar{y})}{\sum (x_i - \bar{x})^2}$$

$$\beta_0 = \bar{y} - \beta_1 \bar{x}$$

## Asumsi Klasik (LINE)
- **L**inearity — hubungan linier.
- **I**ndependence — error tidak berkorelasi.
- **N**ormality — error berdistribusi normal.
- **E**qual variance (homoskedastisitas) — variansi error konstan.

## Studi Kasus PANDORA
Hubungan jumlah hari kerja dalam bulan (X) dengan total jam kerja kumulatif per pegawai (y):
$$y = 0.5 + 8.1 \cdot x$$

Interpretasi: tiap tambah 1 hari kerja, akumulasi jam kerja bertambah ~8.1 jam (sesuai kebijakan 8 jam/hari, sisa adalah lembur).

```python
from sklearn.linear_model import LinearRegression
lr = LinearRegression()
lr.fit(X_train, y_train)
print(lr.coef_, lr.intercept_)
```

## Pitfalls
- Korelasi ≠ kausalitas. Slope signifikan bukan berarti X menyebabkan y.
- Outlier ekstrem dapat menarik garis dramatis.
- Jika hubungan tidak linier, regresi linier salah model.

## Kaitan
- → [Regresi Linier Berganda](03-regresi-linier-berganda.md)
- → [Performance Regresi](04-performance-regresi.md)

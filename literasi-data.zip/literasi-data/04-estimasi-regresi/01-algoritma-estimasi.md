# Algoritma Estimasi

**Kategori:** Estimasi & Regresi | **Level:** Dasar

## Ringkasan
Algoritma estimasi adalah supervised learning yang outputnya nilai kontinu (regresi), bukan label kategori (klasifikasi). Tujuan: memetakan fitur ke angka real.

## Perbedaan dengan Klasifikasi
| Aspek | Klasifikasi | Estimasi/Regresi |
|-------|-------------|------------------|
| Output | Label diskrit | Nilai kontinu |
| Contoh target | "Disiplin/Tidak" | Menit keterlambatan |
| Loss umum | Cross-entropy | MSE/MAE |
| Metrik | Akurasi/F1 | RMSE/MAE/MAPE |

## Algoritma Populer
- **Linear Regression** — paling sederhana, asumsi hubungan linier.
- **Polynomial Regression** — perluasan untuk hubungan non-linier.
- **Ridge / Lasso / Elastic Net** — regresi dengan regularisasi.
- **Decision Tree Regressor**
- **Random Forest Regressor**
- **Gradient Boosting (XGBoost, LightGBM)**
- **Support Vector Regression (SVR)**
- **Neural Network Regressor**

## Studi Kasus PANDORA
Memprediksi total menit keterlambatan harian per OPD. Input: jumlah pegawai aktif, hari kerja, cuaca, hari setelah libur. Output: estimasi menit (kontinu).

```python
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor

model = RandomForestRegressor(n_estimators=200)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
```

## Pitfalls
- Memaksa target kontinu menjadi kelas (lalu pakai klasifikasi) sering kehilangan informasi.
- Asumsi linieritas seringnya salah; selalu plot residu.

## Kaitan
- → [Regresi Linier](02-regresi-linier.md)
- → [Performance Regresi](04-performance-regresi.md)

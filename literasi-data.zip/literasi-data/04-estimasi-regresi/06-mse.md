# Mean Square Error (MSE)

**Kategori:** Estimasi & Regresi | **Level:** Dasar

## Ringkasan
MSE adalah rata-rata kuadrat error. Loss function default banyak algoritma regresi karena diferensiabel dan menghukum error besar secara kuadratik.

## Rumus
$$\text{MSE} = \frac{1}{n} \sum_{i=1}^{n} (y_i - \hat{y}_i)^2$$

## Karakteristik
- Satuan = target² (kurang intuitif untuk laporan).
- Sangat sensitif outlier.
- Sering dipakai sebagai loss training, RMSE untuk pelaporan.

## Hubungan dengan RMSE
RMSE = √MSE. Keduanya membawa informasi sama untuk perbandingan; pilih RMSE jika ingin satuan sama dengan target, MSE jika untuk optimisasi/turunan.

## Studi Kasus PANDORA
Dari contoh sebelumnya: MSE = 8 menit².

Interpretasi langsung sulit ("kuadrat menit"?), tetapi berguna sebagai loss saat training:

```python
from sklearn.metrics import mean_squared_error
mse = mean_squared_error(y_true, y_pred)
```

Pada gradient descent, gradien MSE bersih dan mudah dihitung — alasan utama mengapa MSE jadi pilihan default dalam neural network regresi.

## Pitfalls
- Karena dikuadratkan, satu outlier besar bisa mendominasi.
- Tidak cocok jika prioritasnya error median (gunakan MAE).

## Kaitan
- → [RMSE](05-rmse.md), [MAE](07-mae.md)
- → [Performance Regresi](04-performance-regresi.md)

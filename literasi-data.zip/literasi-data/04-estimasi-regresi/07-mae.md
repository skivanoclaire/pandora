# Mean Absolute Error (MAE)

**Kategori:** Estimasi & Regresi | **Level:** Dasar

## Ringkasan
MAE adalah rata-rata nilai absolut error. Memberi bobot sama pada setiap error (tidak dikuadratkan), sehingga lebih tahan terhadap outlier dibanding MSE/RMSE.

## Rumus
$$\text{MAE} = \frac{1}{n} \sum_{i=1}^{n} |y_i - \hat{y}_i|$$

## Karakteristik
- Satuan sama dengan target.
- Kurang sensitif outlier daripada RMSE.
- Interpretasi: "rata-rata model meleset X unit".

## Kapan Pakai MAE?
- Outlier dianggap anomali yang tidak ingin dikejar.
- Anda ingin metrik yang memberi weight sama untuk semua sample.
- Stakeholder minta angka yang mudah ("rata-rata meleset N menit").

## Studi Kasus PANDORA
Dari contoh keterlambatan:

| Aktual | Prediksi | \|Error\| |
|--------|----------|-----------|
| 5 | 4 | 1 |
| 10 | 12 | 2 |
| 0 | 3 | 3 |
| 20 | 15 | 5 |
| 2 | 1 | 1 |

MAE = (1+2+3+5+1)/5 = **2.4 menit**.

Bandingkan RMSE = 2.83. MAE lebih kecil karena outlier (error 5) tidak dikuadratkan.

```python
from sklearn.metrics import mean_absolute_error
mae = mean_absolute_error(y_true, y_pred)
```

## Pitfalls
- MAE tidak diferensiabel di 0 (absolute value) — bisa menyulitkan beberapa algoritma optimisasi.
- Jika ingin sensitif outlier (karena biayanya mahal), jangan pakai MAE.

## Kaitan
- → [RMSE](05-rmse.md), [MSE](06-mse.md), [MAPE](08-mape.md)
- → [Performance Regresi](04-performance-regresi.md)

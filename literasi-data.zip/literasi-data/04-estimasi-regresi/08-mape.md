# Mean Absolute Percentage Error (MAPE)

**Kategori:** Estimasi & Regresi | **Level:** Dasar

## Ringkasan
MAPE adalah rata-rata error absolut dinyatakan dalam persen dari nilai aktual. Mudah dikomunikasikan ke non-teknis karena bersatuan persen.

## Rumus
$$\text{MAPE} = \frac{100\%}{n} \sum_{i=1}^{n} \left| \frac{y_i - \hat{y}_i}{y_i} \right|$$

## Karakteristik
- Satuan persen, skala bebas.
- Mudah dibandingkan antar dataset.
- Intuitif: "meleset 10% rata-rata".

## Studi Kasus PANDORA
Prediksi total jam kerja pegawai per bulan:

| Aktual | Prediksi | \|Error\|/Aktual |
|--------|----------|------------------|
| 160 | 150 | 6.25% |
| 170 | 175 | 2.94% |
| 155 | 160 | 3.23% |
| 165 | 158 | 4.24% |

MAPE = (6.25+2.94+3.23+4.24)/4 ≈ **4.17%**.

Interpretasi: model meleset rata-rata 4.17% dari nilai aktual. Sangat bagus untuk forecasting.

```python
import numpy as np
mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
```

## Kriteria Umum MAPE
| MAPE | Interpretasi |
|------|--------------|
| <10% | Sangat akurat |
| 10-20% | Baik |
| 20-50% | Cukup |
| >50% | Tidak akurat |

## Pitfalls
- **Meledak saat y=0** atau sangat kecil → pakai SMAPE, MASE, atau WAPE sebagai alternatif.
- Asimetris: under-predict (prediksi < aktual) dan over-predict (prediksi > aktual) dihukum berbeda secara persentase.
- Kurang cocok untuk target yang bisa negatif.

## Kaitan
- → [MAE](07-mae.md), [RMSE](05-rmse.md)
- → [Performance Regresi](04-performance-regresi.md)

# Regresi Linier Berganda

**Kategori:** Estimasi & Regresi | **Level:** Menengah

## Ringkasan
Regresi linier berganda mengekstensi regresi sederhana dengan >1 variabel independen. Output tetap kontinu, tapi dipengaruhi banyak fitur sekaligus.

## Model
$$y = \beta_0 + \beta_1 x_1 + \beta_2 x_2 + \ldots + \beta_n x_n + \epsilon$$

Setiap $\beta_i$ menunjukkan kontribusi $x_i$ **setelah mengontrol** fitur lain.

## Interpretasi Koefisien
"Ceteris paribus" — jika $x_1$ naik 1 unit, y diprediksi berubah sebesar $\beta_1$, dengan asumsi variabel lain tetap.

## Evaluasi Model
- **R²** — proporsi variansi y yang dijelaskan model.
- **Adjusted R²** — R² yang dikoreksi jumlah fitur; lebih adil dibandingkan jika jumlah fitur berbeda.
- **F-test** — apakah model secara keseluruhan signifikan.
- **t-test per koefisien** — apakah fitur signifikan individual.

## Multikolinearitas
Jika dua fitur sangat berkorelasi, koefisien jadi tidak stabil. Deteksi dengan **VIF** (Variance Inflation Factor); VIF > 10 = masalah.

## Studi Kasus PANDORA
Memprediksi total menit keterlambatan harian per OPD:
$$y = 15 + 2.1 \cdot \text{pegawai\_aktif} + 12.3 \cdot \text{hari\_setelah\_libur} - 0.8 \cdot \text{curah\_hujan}$$

Interpretasi sederhana: setiap pegawai tambah ~2.1 menit kumulatif; hari setelah libur menambah 12.3 menit; hujan deras (cuaca buruk) justru mengurangi keterlambatan? — pemeriksaan lebih lanjut diperlukan (mungkin banyak izin).

```python
from sklearn.linear_model import LinearRegression
lr = LinearRegression()
lr.fit(X, y)  # X shape (n, k)
```

## Pitfalls
- Multikolinearitas bikin t-test menipu.
- Fitur tidak relevan menurunkan adjusted R².
- Masih terikat asumsi linier — gunakan polynomial/interaction term jika perlu.

## Kaitan
- → [Regresi Linier](02-regresi-linier.md)
- → [Feature Engineering](../02-data-engineering/11-feature-engineering.md)

# Performance Regresi

**Kategori:** Estimasi & Regresi | **Level:** Dasar

## Ringkasan
Karena target regresi kontinu, metrik yang digunakan mengukur seberapa jauh prediksi dari nilai sebenarnya. Beberapa metrik utama: MSE, RMSE, MAE, MAPE, R².

## Ringkasan Metrik

| Metrik | Satuan | Sensitif outlier | Interpretasi |
|--------|--------|------------------|--------------|
| MAE | = target | Rendah | Rata-rata kesalahan absolut |
| MSE | target² | Tinggi | Rata-rata kesalahan kuadrat |
| RMSE | = target | Tinggi | Akar MSE, satuan sama target |
| MAPE | % | Sedang | Persentase kesalahan |
| R² | - | - | Proporsi variansi dijelaskan |

## Memilih Metrik
- Target kecil bercampur besar, outlier = data nyata → **RMSE/MSE** (hukum besar).
- Outlier = anomali yang tidak ingin dikejar → **MAE**.
- Butuh angka yang mudah dipahami stakeholder → **MAPE**.
- Butuh "goodness of fit" → **R²**.

## Residual Analysis
Selain metrik angka, selalu periksa:
- Plot residu vs prediksi (harus random, tanpa pola).
- Q-Q plot residu (harus dekat garis lurus).
- Histogram residu (harus normal-ish).

## Studi Kasus PANDORA
Model memprediksi total menit keterlambatan harian per OPD.
- RMSE = 18 menit → prediksi meleset ~18 menit rata-rata.
- MAPE = 12% → kesalahan relatif.
- R² = 0.78 → model menjelaskan 78% variansi.

## Pitfalls
- MAPE meledak saat target = 0 atau mendekati nol.
- R² bisa sangat tinggi walau model overfit; pakai validation set.
- RMSE tanpa konteks skala sulit dibaca.

## Kaitan
- → [RMSE](05-rmse.md), [MSE](06-mse.md), [MAE](07-mae.md), [MAPE](08-mape.md)
- → [Algoritma Estimasi](01-algoritma-estimasi.md)
